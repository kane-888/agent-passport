agent-passport Alpha desktop portable package

1. Install Node.js 20 or newer.
2. Run the launcher for your platform.
3. The local product home opens at http://127.0.0.1:4319/.
4. Choose Create Passport or Login / Restore Passport on the first screen.
5. Create, login, recovery, and repair flows stay on this local machine.

This portable package is the Alpha bridge before native installers.
