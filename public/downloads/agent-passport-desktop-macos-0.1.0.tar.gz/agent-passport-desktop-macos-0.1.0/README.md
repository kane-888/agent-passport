# agent-passport

这是 `agent-passport` 当前对应的工程仓库。

## 线程公约

- 先由主控串行收口目标、边界、验收和关键依赖。
- 只有独立任务、明确边界、写入范围不冲突时，才最小必要并行。
- 质量与发布、基础设施可靠性需要介入时，提前并行，不等最后补位。

`agent-passport` 是对外产品名。`记忆稳态引擎` 是底层模型、本地推理、记忆压缩与稳态维持的本体；本线程的方向是把这套底层本体并入 `agent-passport` 运行栈，由 `agent-passport` 负责连续身份、长期偏好、恢复、长期记忆与审计。`openneed` 只是消费这套运行栈构建出来的 app，不属于当前底层本体。

长期方向设想仍然是：

`给 Agent 建一套可校验、可分叉、可授权、可追溯的身份语义与证据约定。`

但当前第一阶段的真实产品定位已经收敛成：

`单机单 Agent、本地优先、可恢复、可审计的 Agent Runtime。`

也就是说，当前最先要做稳的不是“全球协议”，而是：

- 当前单个本地参考层默认只绑定一个 resident agent
- 身份、记忆、权限、证据在线程外、本机内持续存在
- Agent 忘了时先查本地纪要 / 决策 / 证据 / compact boundary，再恢复
- 动作按风险分级：low 保持低延迟，high 先确认，critical 才升级到多签冷路径
- 关键身份和授权事件再进入 DID / VC / 多签 / 本地记录这条冷路径

更完整的人类可读定位文档见：

- [docs/layer-boundary-correction.md](docs/layer-boundary-correction.md)
- [docs/alpha-product-acceptance-checklist.md](docs/alpha-product-acceptance-checklist.md)
- [docs/product-positioning.md](docs/product-positioning.md)
- [docs/mvp.md](docs/mvp.md)
- [docs/ledger-hardening-refactor-report.md](docs/ledger-hardening-refactor-report.md)
- [docs/security-architecture.md](docs/security-architecture.md)
- [docs/operator-security-handbook.md](docs/operator-security-handbook.md)
- [docs/formal-recovery-sop.md](docs/formal-recovery-sop.md)
- [docs/cross-device-recovery-rehearsal.md](docs/cross-device-recovery-rehearsal.md)
- [docs/recovery-cadence-policy.md](docs/recovery-cadence-policy.md)
- [docs/next-phase-security-checklist.md](docs/next-phase-security-checklist.md)

仓库目录名和对外产品名统一为 `agent-passport`；公开底层引擎名统一为 `记忆稳态引擎`。旧 `OpenNeed` 命名只应作为历史数据解析、迁移、环境变量兼容和内部脚本别名保留，不应再作为公开产品文案或用户可见运行态标签。

第一版不直接上真实区块链，而是先做一条本地可校验完整性的链式账本：

- 每个身份事件都带 `previousHash`
- 每次注册、复制、授权都会写成一条带链式哈希的本地历史记录
- 复制体会拥有新的身份编号，并且保留“从谁分叉而来”的痕迹
- 每个 Agent 都会生成本地 DID 和钱包地址
- 授权会校验单签或多签审批人
- 资产授权不会自动继承，必须由来源身份明确授权

## 当前边界

下面这些说法在当前阶段不应该对外讲成“已经实现”：

- 不是全球唯一身份，只是当前本地命名空间内的稳定身份
- 不是第三方独立背书网络，只是本地可校验、可回放的记录体系
- 不是无限自动执行代理，只是在本地门禁通过时具备有限次、可观察、可被拦截的自动恢复/续跑闭环
- 不是可训练的类脑神经网络，只是已经具备类脑启发式记忆分层和运行态摘要层
- 不是不可篡改链上账本，只是具备本地加密、哈希链和完整性校验

## 当前能力

- 注册一个 Agent 身份
- 查询 Agent 列表与单个 Agent 详情
- 从某个 Agent 分叉出新的 Agent 身份
- 给目标 Agent 发放初始资源 / 授权资产
- 查看与更新 Agent 的 DID / 钱包 / 多签策略
- 绑定多个浏览器窗口到同一个 Agent
- 在 Agent 维度记录记忆并路由消息
- 创建、签署、执行和撤销多签授权提案
- 导出 Agent / 授权提案的本地证据包
- 比较两个 Agent，并导出本地可校验的比较审计证据包
- 导出/读取 VC 状态列表和当前账本内可校验的撤销状态证明
- 按 Agent 身份域分组管理多个状态列表
- 在前端切换并浏览不同 issuer 的状态列表
- 在前端并排对比两个状态列表的摘要、条目和证据哈希
- 发布 `agent-passport` 的机器可读产品 / 接口元描述
- 校验当前账本内本地证据包的哈希、发行者与签名
- 默认签发 `did:agentpassport:`，并兼容读取历史 `did:openneed:`
- 用分层记忆 + context builder + memory compactor + 回复校验器缓解身份漂移和部分上下文坍缩
- 用 agent runner 把 context builder / reasoner / 回复校验 / compactor / checkpoint 串成执行闭环
- 用 session state / compact boundary / integrity self-check run 把运行时状态、恢复点和 runtime integrity 自检显式化
- 用 runtime bootstrap 建最小冷启动包，并支持从 compact boundary 恢复上下文
- 用单机 resident agent 绑定把“当前本地参考层默认只服务一个 Agent”显式化
- 默认以 `local_only` 模式离线运行，并只在明确允许时切到 `online_enhanced`
- 服务默认只绑定到 `127.0.0.1`
- `/api` 写接口默认要求本机 `管理令牌`
- 用风险分级策略替代“所有动作都多签”，让 low risk 保持低延迟、critical 才升级到 multisig 冷路径
- 用本地对话纪要 + runtime search 让 Agent 忘了时先查本地纪要 / 决策 / 证据 / compact boundary，再重建上下文
- 默认把 runtime search 收敛成 `local_first_non_vector`，先走 lexical / tag / field 检索，不把向量库当第一阶段前提
- 本地参考层默认以加密 envelope 落盘，而不是继续把账本明文写回磁盘
- 正式恢复流程会派生出一条可执行 runbook，明确下一步、最近证据、是否可以直接跑恢复演练、是否可以导出初始化包
- 受限执行层除了 broker / worker 隔离外，还会在 macOS 上尽量落到 `sandbox-exec` 系统 sandbox，并把结果回写到运行时证据
- 自动恢复 / 续跑闭环不仅返回实时 closure，还会把收口审计落盘到 runner history 和 ledger event，便于事后追踪
- 查看完整链式事件账本
- 在浏览器里操作最小 demo 页面

## 启动

在项目根目录执行：

```bash
node src/server.js
```

或者：

```bash
npm run dev
```

## 公网部署基线

这条服务不是 `Vercel serverless` 场景。先不要从平台品牌出发，只看运行真相。当前最小正确部署前提只有 3 条：

- 单实例长驻进程
- 持久盘保存 ledger / archive / recovery 数据
- 用环境变量注入密钥，不依赖 macOS keychain

当前推荐先按“通用单机长驻进程基线”跑通，再决定你落在哪个云厂商或哪台机器上。仓库里已经补了这组最小可运行模板：

- `Dockerfile`
- `deploy/docker-compose.example.yml`
- `deploy/.env.example`
- `deploy/agent-passport.service.example`
- `deploy/agent-passport.systemd.env.example`
- `deploy/bootstrap-self-hosted-systemd.example.sh`
- `deploy/nginx.agent-passport.conf.example`
- `docs/deployment-baseline.md`
- `docs/self-hosted-go-live-runbook.md`

最短落地步骤：

1. 准备一台 Linux 长驻主机，挂一块持久目录，例如 `/var/lib/agent-passport`
2. 复制 `deploy/.env.example` 为 `deploy/.env`，填入自己的令牌和密钥
3. 在仓库根目录执行 `docker compose --env-file deploy/.env -f deploy/docker-compose.example.yml up -d --build`
4. 如果需要公网入口，再由 Nginx / Caddy / 云负载均衡把你的域名转发到这台服务；仓库已附 `deploy/nginx.agent-passport.conf.example`

这套基线同样适合中国大陆常见云主机，因为它不依赖特定 PaaS，也不要求系统 keychain。

如果你不想用 Docker，也可以直接走 `systemd`：

1. 把代码放到例如 `/opt/agent-passport/current`
2. 把 `deploy/agent-passport.systemd.env.example` 复制到 `/etc/agent-passport/agent-passport.env`
3. 把 `deploy/agent-passport.service.example` 放到 `/etc/systemd/system/agent-passport.service`
4. 执行 `sudo systemctl daemon-reload && sudo systemctl enable --now agent-passport`

最小环境变量口径是：

```bash
PORT=4319
HOST=0.0.0.0
AGENT_PASSPORT_USE_KEYCHAIN=0
AGENT_PASSPORT_LEDGER_PATH=/var/data/ledger.json
AGENT_PASSPORT_RECOVERY_DIR=/var/data/recovery-bundles
AGENT_PASSPORT_ARCHIVE_DIR=/var/data/archives
AGENT_PASSPORT_SETUP_PACKAGE_DIR=/var/data/device-setup-packages
AGENT_PASSPORT_ADMIN_TOKEN=<secret>
AGENT_PASSPORT_STORE_KEY=<secret>
AGENT_PASSPORT_SIGNING_MASTER_SECRET=<secret>
```

其中：

- `PORT`：容器内监听端口；如果你走反向代理或负载均衡，通常保持 `4319` 即可
- `AGENT_PASSPORT_ADMIN_TOKEN`：给 `agent-passport` 管理面和写回桥接用
- `AGENT_PASSPORT_STORE_KEY`：账本加密密钥
- `AGENT_PASSPORT_SIGNING_MASTER_SECRET`：签名主密钥

说明：

- 上面这组路径默认对应 Docker / 容器内挂载点 `/var/data`
- 如果你走 `systemd`，直接改用 `deploy/agent-passport.systemd.env.example` 里的 `/var/lib/agent-passport/...`
- `OPENNEED_LEDGER_PATH` 仍可作为历史兼容别名使用，但新部署应统一改用 `AGENT_PASSPORT_LEDGER_PATH`

如果你需要更完整的单机部署说明，直接看 [docs/deployment-baseline.md](docs/deployment-baseline.md)。

如果你准备实机上线，直接按 [docs/self-hosted-go-live-runbook.md](docs/self-hosted-go-live-runbook.md) 执行。

如果你想把“本机 loopback 检查 + smoke:all + 统一 go-live 判定”压成一条命令，直接执行：

```bash
AGENT_PASSPORT_DEPLOY_BASE_URL=https://你的公网域名 \
AGENT_PASSPORT_DEPLOY_ADMIN_TOKEN=你的管理令牌 \
npm run verify:go-live:self-hosted
```

这条统一 verdict 会跑不跳过浏览器的 `smoke:all`，因此执行机需要具备 Safari DOM automation。Linux 自托管目标机通常先完成服务、恢复基线和 `prepare:self-hosted:pre-public`；最终上线验收通常移到 macOS/Safari 验收机上带真实公网地址执行，除非当前目标机本身已经具备 Safari DOM automation。

如果你是在仓库目录里直接运行，可以写进 `deploy/.env`。
如果你是按 `systemd` / 目标机 release 方式部署，默认应该写进 `/etc/agent-passport/agent-passport.env`，因为 `deploy/.env` 不会随 release 一起同步上机。

如果你的配置文件不在这两个默认位置，可以直接指定：

```bash
AGENT_PASSPORT_DEPLOY_ENV_FILE=/绝对路径/agent-passport.env npm run verify:go-live:self-hosted
```

说明：

- 这条命令默认会先检查本机 `http://127.0.0.1:4319` 的 `/api/health` 和 `/api/security`
- 本机 `/api/security` 这一跳会要求 `releaseReadiness.failureSemantics` 和 `automaticRecovery.failureSemantics` 直接可读
- 只有本机 loopback 真值通过后，才会继续跑 `smoke:all` 和统一 `verify:go-live` 子流程
- 如果你的本机 loopback 不是默认的 `127.0.0.1:4319`，先设置 `AGENT_PASSPORT_SELF_HOSTED_LOCAL_BASE_URL`，或者把 `PORT` / `HOST` 写进对应 env 文件

如果你还在用 Render：

- `render.yaml` 现在只保留为历史兼容模板，不再是默认部署基线
- 当前文件里仍保留一组历史 Render 资源名，用来对接已有部署资源
- 在没有先去部署平台核对“现在线上到底绑定了哪个 service / disk / default domain”之前，不要直接把这些名字机械改成 `agent-passport`

部署完成后先跑：

```bash
AGENT_PASSPORT_DEPLOY_BASE_URL=https://你的公网域名 \
AGENT_PASSPORT_DEPLOY_ADMIN_TOKEN=你的管理令牌 \
npm run verify:deploy:http
```

如果你是在仓库目录里直接运行，并且这些键已经写进 `deploy/.env`，`verify:deploy:http` 会自动读取。
如果你是按 `systemd` / 目标机 release 方式部署，并且这些键已经写进 `/etc/agent-passport/agent-passport.env`，它也会自动读取。

说明：

- `verify:deploy:http` 默认是平台无关的，只会检查你显式提供的 `AGENT_PASSPORT_DEPLOY_BASE_URL`，或者你显式给出的 `AGENT_PASSPORT_DEPLOY_BASE_URL_CANDIDATES`
- 只有在你明确设置 `AGENT_PASSPORT_DEPLOY_RENDER_AUTO_DISCOVERY=1` 时，它才会再从 `render.yaml` 自动推导 `*.onrender.com` 候选地址

这条验证会同时检查：

- `/` 公开运行态入口能正常返回 HTML
- `/api/health`、`/api/capabilities`、`/api/security` 可公开访问
- `/api/security.releaseReadiness.failureSemantics` 和 `/api/security.automaticRecovery.failureSemantics` 必须可直接读取
- `/api/agents` 在无 token 时返回 `401`
- `/api/agents` 在带 admin token 时返回 `200`

验证通过后，如果你还在接旧 OpenNeed 侧桥接，再把这个公网地址回填到 `OPENNEED_AGENT_PASSPORT_URL`。这是 legacy compatibility 入口，不是 agent-passport 当前对外命名。

如果要做本地回归，或者直接做正式放行前的本地门禁，统一执行：

```bash
npm run smoke:all
```

如果要分别看每一层，也可以继续单独执行：

```bash
npm run smoke:dom
npm run smoke:dom:core
npm run smoke:ui
npm run test:smoke:guards
npm run smoke:operational
npm run smoke:all:ci
npm run soak:runtime:operational
npm run demo:context
npm run history:wording:audit
```

其中：

- `npm run test:smoke:guards`
  说明：只跑 smoke / operational / browser / runner / pre-public 的脚本级守门测试，确认新增脚本、语义汇总、`smoke-ui-http` token fallback、fetch/body 防超时、passive store read、offline-chat runtime、remote reasoner context、auto-recovery、公网前恢复基线刷新和 clean-clone 跟踪清单不会因为漏文件、漏 npm 入口或漏 git 跟踪而静默丢失。它是提交前的轻量防丢入口，不替代真实运行态 smoke
- `npm run smoke:dom`
  说明：默认执行 combined DOM 真值口径，不依赖浏览器，但会覆盖公开入口、修复中枢、恢复/备份、device setup、离线线程和自动 fan-out 的主要 agent-native 契约。它是拆层排查时的默认 DOM 门禁。
- `npm run smoke:dom:core`
  说明：只跑轻量 DOM 契约，不做完整 combined/operational 生命周期；用于快速定位 HTML/共享链接/选择器契约漂移，不作为正式放行口径
- `npm run smoke:ui`
  说明：默认会自起一个隔离的 loopback server，并复制一份临时 data / keychain namespace，再对这台受控本地服务做一轮运行态契约 smoke；如果你显式传入 `AGENT_PASSPORT_BASE_URL`，则会复用那台指定服务
  当前会覆盖公开运行态 / 修复中枢 / 离线线程入口、管理令牌与 read session 边界、本地存储加密与恢复流程、受限执行层、以及自动恢复 / 续跑闭环；脚本会显式建立它自己需要的最小 runtime 前置条件，不再依赖“之前有人跑过别的入口”。`keychain-migration` 只会在 `/api/security` 当前真值显示仍需从文件回退迁到系统保护层时才探测，不会把“已经达标”的状态误判成失败
- `npm run smoke:operational`
  说明：只跑 operational UI / DOM 生命周期，不跑 combined DOM、浏览器和远端 reasoner preflight；用于快速回答“本地 reasoner 恢复、setup package、conversation memory/runtime search、sandbox audit、execution history、housekeeping apply、自动恢复 / 续跑闭环是否真的可用”。它不是 `smoke:all` 的替代品，但当长链路被外层执行器打断时，它是主运行态生命线的短门禁
  拆层排查时也可以直接跑 leaf 入口：`npm run smoke:ui:operational` 只看 HTTP/UI 运行态生命周期，`npm run smoke:dom:operational` 只看 ledger/setup/housekeeping 的 DOM-free 操作闭环
- `npm run smoke:all`
  说明：先做 `verify:mempalace:remote-reasoner` preflight，再按 `smoke:ui -> smoke:dom -> smoke:browser -> smoke:ui:operational -> smoke:dom:operational` 执行；默认会自起一个隔离的 loopback server，并同时隔离临时 data 副本、管理令牌文件回退路径、signing secret 文件回退路径和 keychain account namespace，避免多人开发时复用正在变化的本地进程，或者把 smoke 写回真实工作数据 / 真实系统保护层。这是当前唯一完整的本地门禁入口
  当前会明确拦截这 5 类退化：
  - DOM 真执行层没有进入 `automatic_fanout`，或者并行批次 / 最新历史并行批次统计缺失
  - 浏览器真页面里群聊没有显示调度历史、并行批次 chip 不见了、单聊没有隐藏调度历史、或群聊发送后侧栏没有刷新到新一轮
  - 浏览器真页面没有把 `threadProtocol / protocolSummary` 这份协议真值渲染出来
  - 浏览器页面上下文虽然能打开，但已经读不到 `/api/security.releaseReadiness.failureSemantics`、`/api/security.automaticRecovery.failureSemantics` 或事故交接包里的对应真值
  - operational UI / DOM 生命周期没有证明本地 reasoner 恢复、setup package、housekeeping apply、受限执行审计、自动恢复 / 续跑闭环可用
  - `operationalFlowSemantics.status` 和 `runtimeEvidenceSemantics.status` 没有同时通过
  结果怎么看：
  - 通过时会看到 `offlineFanoutGate`、`protectiveStateSemantics`、`operationalFlowSemantics`、`runtimeEvidenceSemantics` 和 `browserUiSemantics` 都没有失败
  - 失败时会直接报哪一层没过，不需要先翻长 JSON
  - 失败分流先看 `docs/go-live-operations-checklist.md` 的“失败先按这张表分流”：`smoke:browser` 看 `blocker / failedSurface / nextAction`，`soak:runtime` 看 `failedRounds / failedSharedStateRounds / coverage.browserUi`，admin token 和 read-session 失败先判权限边界，不要直接当运行态坏掉
- `npm run smoke:all:ci`
  说明：和 `smoke:all` 使用同一套语义门禁，仍会先跑 remote reasoner preflight，但显式跳过 `smoke:browser`，并通过 `SMOKE_ALL_PARALLEL=1` 让 combined UI/DOM 和 operational UI/DOM leaves 都按可并行路径收口；因此它适合无 Safari DOM automation 的 CI / 远端环境，但日志顺序和串行本地 smoke 不完全一样，只能当环境退化替身，不是正式本地放行入口
  如果你要把 CI 结果用于放公网前判断，还必须在能跑 Safari DOM automation 的本机或目标验收机补 `npm run smoke:browser`，或者直接跑不跳过浏览器的 `npm run smoke:all`
- `npm run demo:context`
  说明：使用临时 ledger 跑一轮“缓解上下文坍缩”最小回归，不污染你当前真实账本
  当前会验证：
  - runtime bootstrap 会先写 profile / task snapshot / runtime truth-source 约束记录
  - bootstrap 可以顺手认领当前本地参考层的 resident agent 绑定
  - profile / episodic / semantic / working / ledger 五层记忆
  - runner 先按本地参考层重建上下文，再调用 `local_mock` reasoner 生成候选回复
  - memory compactor 把多轮聊天写回结构化 memory
  - context builder 不是拼整段聊天，而是按槽位重建
  - 回复校验器能拦住错误的 `agent_id / role / name / wallet`
- `npm run history:wording:audit`
  说明：扫描 `data/` 里的历史账本、backup、setup package 和 archive，找出还没迁走的旧包装词；默认只做 dry-run，不改真实文件
- `npm run history:wording:apply`
  说明：把上面的历史措辞迁移真正写回历史文件；默认仍然跳过 `data/ledger.json`，只有显式加 `--include-live-ledger` 才会改当前真实账本
  - working memory 超阈值后会自动 rollover 成 checkpoint summary
  - compact boundary 生成后，runner / rehydrate 可以从 boundary 后继续恢复
  - 可以把本地对话纪要写进 本地参考层，并用 runtime search 把纪要 / 决策 / 证据重新搜回来
  - `openai_compatible` reasoner 会通过本地 stub 走一遍真实 LLM provider 契约
  - `local_only` 模式下，在线 provider 会自动降级到离线 provider，避免偷偷联网
  - 这条脚本主要验证身份字段和恢复链，不代表通用语义恢复已经可靠

如果你在 macOS 上，还可以直接跑 Safari 浏览器级回归：

```bash
npm run smoke:browser
```

说明：

- 这条浏览器级回归默认使用 Safari
- 默认会像 `smoke:ui` 一样自起一台隔离的 loopback server，并隔离临时 data / secret / keychain namespace；如果显式传入 `AGENT_PASSPORT_BASE_URL`，才会复用指定服务
- 这条回归会用 Safari DOM 自动化把 `/` 渲染出的 4 张卡、触发条件列表和可用入口列表，与当前 `/api/health` + `/api/security` 真值逐项比对；如果首页落到读取失败文案，会直接失败
- 优先跑 wrapper 入口 `npm run smoke:browser`，不要直接把 `smoke:browser:raw` 当放行入口；wrapper 会负责隔离 server / data / secret / keychain namespace
- 跑前确认本机没有 stale browser automation lock；脚本会自动等待和清理失效锁，但如果有另一个活跃 Safari smoke 正在跑，应等它结束
- 首次使用前，需要在 Safari 的 Developer 设置里开启 `Allow JavaScript from Apple Events`
- 如果这项没有开启，`smoke:browser` 会明确失败并提示这是本机 Safari 设置问题；它不会再跳过首页 gate 后误判通过

如果你要确认“不是单次能过，而是连续多轮也不会漂”，执行：

```bash
npm run soak:runtime
```

说明：

- 这条长稳脚本现在默认按 `cold start -> shared-state -> crash restart` 顺序收口，不再只是旧口径的冷启动/重启探测
- 默认长稳为了适配 CI / Linux / 无 Safari DOM automation 的机器，会把 browser UI 语义标成 `coverage.browserUi=skipped_by_default`；它证明运行生命线稳定，不证明页面投影真值已经连续稳定
- 默认 `requestedRounds=3`，`sharedStateRounds=min(requestedRounds, 2)`；输出 JSON 会同时给 `coldStartRounds`、`sharedState.rounds` 和 `crashRestart`
- `shared-state` 阶段会复用同一份隔离 data root，专门检查窗口绑定数量不漂、passport memory / conversation minute / runner history / verification history / repair 这些累计计数不倒退
- 如果只要连续压“agent 主运行生命线”，执行 `npm run soak:runtime:operational`；它会把 cold start / shared-state 阶段切到短 `smoke:operational`，仍然强制检查令牌轮换、窗口改绑、自动恢复 / 续跑、runtime evidence、共享态累计和异常退出恢复
- 如果要把 `/`、`/operator`、`/lab.html`、`/repair-hub`、`/offline-chat` 的浏览器投影真值也放进长稳，执行 `npm run soak:runtime:browser`；这条需要 Safari DOM automation，输出会标成 `coverage.browserUi=required`
- 如果你只是想回到旧口径做定位，显式加 `--skip-shared-state`，或设 `AGENT_PASSPORT_SOAK_SKIP_SHARED_STATE=1`
- 如果你想把共享态累计阶段拉长，显式加 `--sharedRounds=N`，或设 `AGENT_PASSPORT_SOAK_SHARED_ROUNDS=N`
- 这条不是替代 `smoke:all`：`smoke:all` 回答“当前这一版本地门禁是否通过”，`soak:runtime` 回答“同一条运行链连续多轮、共享状态累计、异常退出后是否仍稳定”
- 这条也不是替代 go-live verifier：正式上线仍以真实公网地址下的 `verify:go-live:self-hosted` 或 `verify:go-live` 为准；缺 Safari 的默认长稳只能作为运行生命线证据

如果要做发布前拆层预检，当前推荐顺序是：

```bash
npm run smoke:all
AGENT_PASSPORT_DEPLOY_BASE_URL=https://你的公网域名 AGENT_PASSPORT_DEPLOY_ADMIN_TOKEN=你的管理令牌 npm run verify:deploy:http
npm run test:verify:deploy:http
```

第一条负责收口本地隔离回归和 `offline fan-out gate` 门禁，第二条负责收口公网部署验证，第三条负责锁住 deploy 自动发现链路的最小回归。这个组合适合排障和分层确认，不等于最终 go-live verdict；正式上线仍以 `verify:go-live:self-hosted` 或 `verify:go-live` 的统一结论为准。

如果你就在具备 Safari DOM automation 的自托管目标/验收机上做最终验收，直接跑：

```bash
AGENT_PASSPORT_DEPLOY_BASE_URL=https://你的公网域名 AGENT_PASSPORT_DEPLOY_ADMIN_TOKEN=你的管理令牌 npm run verify:go-live:self-hosted
```

如果你是在仓库目录里直接运行，并且这些键已经写进 `deploy/.env`，可以直接裸跑 `npm run verify:go-live:self-hosted`。
如果你是按 `systemd` / 目标机 release 方式部署，并且这些键已经写进 `/etc/agent-passport/agent-passport.env`，也可以直接裸跑。
如果你的配置文件不在默认位置，前面再加一层 `AGENT_PASSPORT_DEPLOY_ENV_FILE=/绝对路径/agent-passport.env` 即可。
这条自托管放行链会先核对本机 loopback 真值；只有本机通过，才继续合并统一 verdict。真正通过时，`readinessClass` 会返回 `self_hosted_go_live_ready`。
注意：统一 verdict 内部会跑不跳过浏览器的 `smoke:all`，当前浏览器门禁依赖 Safari DOM automation。Linux 自托管目标机通常只能完成本机服务、恢复基线和公网前准备；正式上线前还需要在能跑 Safari DOM automation 的验收机上，带真实 `AGENT_PASSPORT_DEPLOY_BASE_URL` 跑 `verify:go-live` 做最终验收。
脚本本体会把最终 verdict JSON 保留在 stdout，`smoke:all` 子流程日志改走 stderr；如果你要接 `jq`、CI 或 shell 自动化，优先用 `npm run --silent verify:go-live:self-hosted`，或者直接调用 `node scripts/verify-self-hosted-go-live.mjs`。

如果你现在还不准备接公网，只想先把“公网前准备”做完，再执行：

```bash
npm run prepare:self-hosted:pre-public
```

这条命令会刷新正式恢复基线：导出一份最新 recovery bundle、立刻做持久化恢复演练、必要时先 prewarm 本地 reasoner 清掉 `local_reasoner_reachable` setup gap，再导出一份和当前恢复基线对齐的 setup package。macOS 默认会把 recovery passphrase 存进 Keychain `AgentPassport.RecoveryPassphrase/resident-default`；如果目标机器没有 Keychain，先显式提供 `AGENT_PASSPORT_RECOVERY_PASSPHRASE`。
它是“放公网前准备”的新鲜度门禁，不是正式上线放行：输出里的 `artifactProof.ok=true` 表示 recovery bundle、rehearsal 和 setup package 都来自同一轮新刷新。若缺少正式公网域名，脚本只做本机 loopback verifier，不触发完整 `smoke:all` / Safari DOM 门禁；本机前提通过时，`ok=true` 会搭配 `readinessClass=pre_public_ready_deploy_pending`，表示“公网前准备完成”，不是“已经正式上线”。若已经提供真实 `AGENT_PASSPORT_DEPLOY_BASE_URL`，脚本才会继续走完整 self-hosted verifier。下一步仍然要在拿到真实公网地址后跑 `verify:go-live:self-hosted` 或 `verify:go-live`。默认只会对 `http://127.0.0.1` 或 `http://localhost` 自动拉起本地运行态；`http://[::1]` 可复用已运行服务但不会自动拉起；非 loopback 地址不会自起服务。需要完全禁止自起时，设置 `AGENT_PASSPORT_PRE_PUBLIC_AUTO_START=0` 后再运行。
pre-public 内部 HTTP 请求默认 `45000ms` 超时，可用 `AGENT_PASSPORT_PRE_PUBLIC_FETCH_TIMEOUT_MS` 调整；setup package 默认只嵌入 1 个 local reasoner profile，可用 `AGENT_PASSPORT_PRE_PUBLIC_LOCAL_REASONER_PROFILE_LIMIT` 调整。`artifactProof.ok=true` 还要求 `setup_package_local_reasoner_profiles_bounded` 通过，避免公网前初始化包把历史 profiles 全量带进去。

如果这条自托管放行链失败，现场优先看：

- `firstBlocker`：当前最先卡住放行的结构化阻塞项
- `operatorSummary`：给人和 agent 先读的一句话结论，已把最先阻塞项、原因和下一步合在一起
- `nextAction`：当前最先该补的动作
- `errorClass` / `errorStage`：给 CLI 包装器、自动化脚本和告警路由做稳定分流；现在 self-hosted verdict 也会直接给出
- `preflightShortCircuited`：只表示 unified go-live 是否在 preflight 阶段就直接短路掉后续链路；像“缺少 deploy URL”这种场景虽然会挡住公网 deploy/runtime 检查，但仍会继续跑本地 `smoke:all`，所以这里仍然是 `false`
- `unifiedSkipped` / `unifiedSkipReason`：一眼看 unified 子流程这次是不是根本没跑；如果是 `local_runtime_blocked`、`config_env_unreadable` 或 `local_runtime_unexpected_error`，都先处理本机前置问题，不要先追 deploy
- 如果 `errorClass=config_env_unreadable`：先检查 `AGENT_PASSPORT_DEPLOY_ENV_FILE` 指向的文件路径、权限，以及当前执行用户是否真的可读
- `effectiveConfig.machineReadableCommand`：需要把结果直接喂给 `jq`、CI 或 wrapper 时，优先用这条命令，不要直接裸跑带 npm banner 的 `npm run verify:go-live:self-hosted`
- `deploy` / `smoke` / `runtimeReleaseReadiness`：这条 self-hosted verdict 现在也会把统一 verdict 里的 deploy、smoke 和运行态摘要直接抬到顶层
- `effectiveConfig`：这次实际读取到的本机地址、公网地址、token 来源和 env 文件来源

如果你不在目标主机上，而是在外部控制台做统一公网验收，再跑：

```bash
AGENT_PASSPORT_DEPLOY_BASE_URL=https://你的公网域名 AGENT_PASSPORT_DEPLOY_ADMIN_TOKEN=你的管理令牌 npm run verify:go-live
```

这条会先做 deploy preflight，再跑 `smoke:all`，最后把浏览器级 `offlineFanoutGate`、deploy HTTP 结果和运行态放行前提合并成一份 JSON 结论；如果 deploy verifier 自身异常，会短路后续 smoke，避免把本地门禁结果误当公网放行结论。重点看：

- `ok=true`：当前已经满足统一放行条件
- `readinessClass=go_live_ready|private_pilot_only|internal_alpha_only|blocked`
- `firstBlocker`：当前最先卡住放行的那一条结构化阻塞项；现场排障优先看它
- `blockedBy[]`：当前到底卡在哪些 deploy / runtime / smoke 前提
- `operatorSummary`：最短排障话术；如果你只想先知道“卡哪、为什么、下一步做什么”，先看它
- `nextAction`：当前最先该补的动作

现在的行为：

- 如果缺少 `AGENT_PASSPORT_DEPLOY_BASE_URL`，`verify:go-live` 会先在 deploy preflight 识别缺口，再继续跑本地 `smoke:all`，然后返回结构化的 `local_ready_deploy_pending` 或 `local_gate_blocked`
- 如果本机 keychain 或 `data/.admin-token` 已经有管理令牌，`verify:deploy:http` / `verify:go-live` 会自动复用，不需要再重复手填 token
- 如果你显式启用了 `AGENT_PASSPORT_DEPLOY_RENDER_AUTO_DISCOVERY=1`，并且 `render.yaml` 还保留历史 Render 资源名，`verify:deploy:http` / `verify:go-live` 会把这件事作为结构化提醒直接报出来
- 如果你只是想先验证本地门禁，不要跑 `verify:go-live`，直接跑 `npm run smoke:all`

推荐环境变量：

- `AGENT_PASSPORT_DEPLOY_BASE_URL`：正式 deploy 的公网地址
- `AGENT_PASSPORT_DEPLOY_ADMIN_TOKEN`：正式 deploy 的管理令牌
- `AGENT_PASSPORT_DEPLOY_ENV_FILE`：可选，自定义 deploy 配置文件绝对路径；它在配置文件候选列表里优先加载，但显式 shell env 值仍优先于 env 文件值
- `AGENT_PASSPORT_DEPLOY_BASE_URL_CANDIDATES`：可选，逗号或空白分隔的候选公网地址；当正式 URL 还没完全确认时，可让 `verify:deploy:http` / `verify:go-live` 先自动逐个探测
- `AGENT_PASSPORT_DEPLOY_RENDER_AUTO_DISCOVERY`：可选；只有你仍在使用 Render，且希望从 `render.yaml` 自动推导 `*.onrender.com` 候选地址时才设为 `1`

配置解析的有效优先级是：显式 shell env 值 -> `AGENT_PASSPORT_DEPLOY_ENV_FILE` 指向的文件 -> 仓库内 `deploy/.env` -> `/etc/agent-passport/agent-passport.env`。文件之间先读到的值会保留，后续文件不会覆盖同名键。

兼容说明：

- `verify:deploy:http` 和 `verify:go-live` 仍兼容旧的 `AGENT_PASSPORT_BASE_URL` / `AGENT_PASSPORT_ADMIN_TOKEN`
- 本机排障时，如果 keychain 或 `data/.admin-token` 已经存在管理令牌，通常只需要显式提供 `AGENT_PASSPORT_DEPLOY_BASE_URL`
- 但如果你不显式提供 deploy 侧环境变量，统一 verdict 现在会直接返回“缺少正式 deploy URL / 管理令牌”的结构化阻塞项，而不再默认撞 `localhost:4319`

默认地址：

- 首页: `http://localhost:4319`
- 实验与维护页: `http://localhost:4319/lab.html`
- 离线协作: `http://localhost:4319/offline-chat`（页面壳可公开访问；启动真值、线程历史、同步和发送消息都走受保护读取或管理令牌边界）
- 线程启动上下文（当前只支持 `phase_1`，受保护读取）: `http://localhost:4319/api/offline-chat/thread-startup-context?phase=phase_1`
- Web UI: `http://localhost:4319`
- 修复中枢: `http://localhost:4319/repair-hub`
- Health: `http://localhost:4319/api/health`
- Security: `http://localhost:4319/api/security`
- Agents: `http://localhost:4319/api/agents`
- Ledger: `http://localhost:4319/api/ledger`

可选环境变量：

- `PORT`
- `AGENT_PASSPORT_CHAIN_ID`
- `AGENT_PASSPORT_LEDGER_PATH`
- `AGENT_PASSPORT_LLM_BASE_URL`
- `AGENT_PASSPORT_LLM_MODEL`
- `AGENT_PASSPORT_LLM_API_KEY`
- `AGENT_PASSPORT_ADMIN_TOKEN`
- `AGENT_PASSPORT_STORE_KEY`
- `HOST`

兼容别名：

- `OPENNEED_CHAIN_ID`
- `OPENNEED_LEDGER_PATH`

旧变量仍会被读取，但只用于历史兼容，不再是新部署推荐入口。

多窗口使用方式：

1. 打开这个页面的两个浏览器窗口或两个标签页。
2. 在两个窗口里都绑定到同一个 `Agent ID`。
3. 你会看到相同的身份、记忆、资产和消息上下文。
4. 每个窗口都有自己的 `windowId`，但背后共享同一个 Agent 中枢。

当前默认设备运行策略：

- 一台设备默认只绑定一个 resident agent
- 默认 resident agent 绑定到当前本地参考层的 canonical agent
- 默认 `local_only`
- 默认 `confirm_before_execute`
- 默认执行授权按风险分级：
  - `low=discuss`
  - `medium=discuss`
  - `high=confirm`
  - `critical=multisig`
- 默认检索策略是 `local_first_non_vector`
- 默认 `allowVectorIndex=false`
- 默认写接口要求本机 `管理令牌`
- 默认敏感读接口也要求本机 `管理令牌`
- 默认 本地参考层 以加密 envelope 落盘

这一步的目标不是“让模型永远不忘”，而是：

`不要让聊天记录成为身份，而是让身份决定每次该取哪些上下文。`

## API

### `GET /api/device/runtime`

读取当前这台机器的本地运行策略。

返回值会包含：

- `machineId`
- `machineLabel`
- `residentAgentId`
- `residentDidMethod`
- `residentDid`
- `residentLocked`
- `localMode`
- `allowOnlineReasoner`
- `commandPolicy`
- `memoryHomeostasis`

`commandPolicy` 当前最重要的字段是：

- `negotiationMode=confirm_before_execute|discuss_first`
- `autoExecuteLowRisk`
- `riskStrategies.low|medium|high|critical`
- `requireExplicitConfirmation`

同时还会返回：

- `retrievalPolicy.strategy=local_first_non_vector`
- `retrievalPolicy.scorer=lexical_v1`
- `retrievalPolicy.allowVectorIndex=false`
- `retrievalPolicy.maxHits`
- `retrievalPolicy.externalColdMemory.enabled=false`
- `retrievalPolicy.externalColdMemory.provider=mempalace`
- `retrievalPolicy.externalColdMemory.maxHits`

`externalColdMemory` 默认关闭。开启后也只是只读冷记忆侧车，只提供候选线索，不覆盖 `ledger/profile/runtime` 本地参考层，也不会写回主记忆。

如果当前候选回复要交给远端 `http/openai_compatible` reasoner，external cold memory 也只会保留 `provider/hitCount` 这类边界信息，不会把候选原文直接发出去。

如果要接本机 `mempalace`，可以显式设置：

- `AGENT_PASSPORT_EXTERNAL_COLD_MEMORY_ENABLED=1`
- `AGENT_PASSPORT_MEMPALACE_PALACE_PATH=/absolute/path/to/palace`

如果只是想把 `agent-passport` 当前仓库的只读冷记忆侧车建起来，直接运行：

- `npm run build:mempalace:live`

这条命令会把当前工程仓库以及同级目录下的 `上下文坍缩测试工具`（如果存在）整理成 staging 语料，再 mine 到默认 sidecar palace。若机器上已有历史兼容目录，运行时仍会优先复用：

- `~/.mempalace/agent-passport-sidecar-palace`

随后可以用下面的命令做真实命中校验：

- `npm run verify:mempalace:live -- "上下文坍缩"`

如果还要确认 sidecar 命中在远端 `http/openai_compatible` reasoner 出站时确实被脱敏，再跑：

- `npm run verify:mempalace:remote-reasoner`

这一步会明确验证：

- `externalColdMemory.hits` 不再透传空壳
- `redactedForRemoteReasoner=true`
- 出站 `payload` 不再带 `recentConversationTurns / toolResults`
- 出站 prompt 不再包含 `EXTERNAL COLD MEMORY CANDIDATES / QUERY BUDGET`

`memoryHomeostasis` 当前会给出 3 层真值：

- `activeModelName / latestModelProfile / resolvedRuntimeProfile`
- `observationSummary.latestObservation / latestUnstableObservation / recent`
- `observationSummary.effectiveness`

其中 `observationSummary.effectiveness` 会量化回答：

- 最近有多少次纠偏请求被真正追回
- `recoveryRate`
- 平均 `cT` 降幅
- 平均 `sT` 回升幅度
- 最近一次“失稳 -> 恢复”配对
- 当前是否还有未追回的失稳样本

如果要直接验证这条链，可以运行：

- `npm run verify:memory-homeostasis`
- `npm run verify:memory-homeostasis -- --mode runner_probe`
- `npm run verify:memory-homeostasis -- --mode escalation_preview`

其中：

- `recompute` 模式验证重算与纠偏落库
- `runner_probe` 模式验证 active probe 与运行态摘要
- `escalation_preview` 模式直接预览“失稳 -> 纠偏 -> 恢复”的量化效果

这个接口适合在 Agent 启动前先读一遍，确认这台设备到底归哪个 resident agent 使用。

### `GET /api/security`

读取当前本机安全基线摘要。

返回值会包含：

- `hostBinding`
- `authorized`
- `authorizedAs=public|admin|read_session`
- `apiWriteProtection.tokenRequired`
- `apiWriteProtection.tokenSource=env|file|keychain`
- `apiWriteProtection.keychainService`
- `apiWriteProtection.keychainAccount`
- `readProtection.sensitiveGetRequiresToken`
- `readProtection.scopedReadSessions`
- `readProtection.availableScopes`
- `localStore.encryptedAtRest`
- `localStore.encryptionSource`
- `localStore.systemProtected`
- `localStore.recoveryEnabled`
- `localStore.recoveryBaselineReady`
- `keyManagement.keychainPreferred`
- `keyManagement.keychainAvailable`
- `keyManagement.storeKey.source=env|keychain|file_record`
- `keyManagement.signingKey.source=env|keychain|file`

当前默认策略是：

- 服务只绑定 `127.0.0.1`
- `/api` 写接口默认要求 `Authorization: Bearer <token>`
- 敏感 `GET` 接口也默认要求 `Authorization: Bearer <token>`
- 读接口除了管理令牌，也支持按 scope 创建短时 read session
- read session 现在也支持 role presets、parent/child delegation 和资源绑定
- 资源绑定已经覆盖 `agents / windows / credentials / authorizations / migration repairs / status lists` 这些敏感读面
- 核心敏感读面现在也支持 endpoint-family 级别的细 scope
- 当前内置的细粒度角色还包括：
  - `authorization_observer`
  - `repair_observer`
  - `status_list_observer`
- macOS 上会优先尝试把 `管理令牌` 放进系统 Keychain，只有不可用时才回退到本地文件
- macOS 上会优先尝试把 store key 和 signing master secret 放进系统 Keychain，只有不可用时才回退到本地文件
- `localStore.encryptedAtRest` / `systemProtected` / `recoveryBaselineReady` 返回的是当前运行态真值，不是“这个功能理论上存在”
- `localStore.keyPath` 只有当前 store key 真走文件回退时才会返回，不再把默认文件位置误报成生效路径
- 未带 token 访问 `/api/security` 时，只返回 redacted 安全摘要，不再暴露本地路径

### `POST /api/security/keychain-migration`

把当前仍走文件回退的 store key / signing master secret 补齐到系统 Keychain。

这是一条迁移/补齐入口，不是每次都必须跑。先看 `GET /api/security`：

- 如果 `keyManagement.storeKey.source` 和 `keyManagement.signingKey.source` 都已经是 `keychain`，直接把当前状态视为已达标，跳过这条接口
- 只有当策略要求系统保护，而且至少一个 key material 还没进 `keychain` 时，才需要调用它

常用字段：

- `dryRun`
- `removeFile`

返回值会同时给出：

- `migration.storeKey`
- `migration.signingKey`

每一项都可能是实际迁移，也可能是 `skipped + reason`；不要把“接口存在”误当成“当前一定需要迁移”。

默认建议先用 `dryRun=true` 看迁移结果，再决定是否真的移除本地文件。

### `GET /api/security/read-sessions`

列出当前本机已签发的 scoped read sessions。

可选参数：

- `includeExpired=true|false`
- `includeRevoked=true|false`

这个接口本身是 admin-only，不接受 read session 反向读取。

### `POST /api/security/read-sessions`

创建一个短时、按 scope 限制的 read session。

常用字段：

- `label`
- `note`
- `role`
- `scopes`
- `agentIds`
- `windowIds`
- `credentialIds`
- `ttlSeconds`
- `parentReadSessionId`
- `canDelegate`
- `maxDelegationDepth`

补充约束：

- 角色化创建会先按 role preset 落默认 scopes
- 子会话的 `scopes` 不能超出父会话的范围
- 子会话的 TTL 不会超过父会话剩余寿命
- 子会话不能扩大 delegation 能力，`maxDelegationDepth` 只会更小
- 子会话不能扩大资源绑定范围，`agentIds / windowIds / credentialIds` 只能收窄
- 父会话一旦撤销或过期，整条子会话链都会失效
- 只有具备 `security` 或 `all` 范围的读会话，才允许继续派生更窄的子会话

当前内置角色：

- `all_read`
- `security_delegate`
- `runtime_observer`
- `recovery_observer`
- `agent_auditor`
- `window_observer`

当前支持的 scope：

- `security`
- `device_runtime`
- `recovery`
- `agents`
- `credentials`
- `authorizations`
- `migration_repairs`
- `status_lists`
- `windows`

补充说明：

- `/api/device/runtime/recovery` 现在单独走 `recovery` scope，不再跟 `device_runtime` 共用一档读权限
- 使用 `read_session` 读取 `/api/security` 或 recovery 列表时，默认会返回 redacted 视图，不暴露本地敏感路径
- 使用 `read_session` 读取 `agents/context/runtime/messages/memories/credentials/rehydrate/search` 时，默认只返回 redacted 观察视图：
  - 自由文本字段会被置空
  - 原始 proof / raw credential body 不再原样透出
  - prompt / local knowledge / runtime notes 只保留结构化元信息

返回值会只在创建当次返回一次明文 `token`；账本里只存哈希。响应里也会返回：

- `parentReadSessionId`
- `rootReadSessionId`
- `lineageDepth`
- `role`
- `canDelegate`
- `maxDelegationDepth`

### `POST /api/security/read-sessions/:id/revoke`

撤销一个已有的 read session。

常用字段：

- `revokedByAgentId`
- `revokedByWindowId`

如果撤销的是父会话，子会话不会被逐条重写成 `revoked`，但会通过祖先链校验统一失效。

### `POST /api/device/runtime`

更新当前这台机器的本地运行策略。

常用字段：

- `residentAgentId`
- `residentDidMethod`
- `localMode=local_only|online_enhanced`
- `allowOnlineReasoner`
- `negotiationMode=confirm_before_execute|discuss_first`
- `autoExecuteLowRisk`
- `lowRiskStrategy=auto_execute|discuss|confirm`
- `mediumRiskStrategy=discuss|confirm`
- `highRiskStrategy=confirm|multisig`
- `criticalRiskStrategy=multisig`
- `requireExplicitConfirmation`
- `retrievalStrategy=local_first_non_vector`
- `allowVectorIndex`
- `retrievalMaxHits`
- `localReasonerEnabled`
- `localReasonerProvider=local_command|local_mock|ollama_local|openai_compatible`
- `localReasonerCommand`
- `localReasonerArgs`
- `localReasonerCwd`
- `localReasonerTimeoutMs`
- `localReasonerMaxOutputBytes`
- `allowedCapabilities`
- `maxReadBytes`
- `maxListEntries`
- `maxProcessArgs`
- `maxProcessArgBytes`
- `maxUrlLength`
- `requireAbsoluteProcessCommand`
- `allowResidentRebind`
- `dryRun`

典型用途：

- 把这台设备认领为某个 canonical agent 的专属机器
- 默认离线运行，只在明确允许时切到联网增强
- 调整“低风险快执行 / 高风险先确认 / critical 才多签”的命令策略
- 明确把恢复检索固定在本地优先、非向量优先
- 给 resident agent 配置本地 `local_command` reasoner，离线时直接从本地参考层 组装上下文后再调用本地进程
- 把可执行能力收口到 allowlist，限制文件读取和目录列举预算

如果通过 `read_session` 读取这个接口，`sandboxPolicy.filesystemAllowlist / networkAllowlist / allowedCommands` 会被置空，只返回对应的 `*Count` 计数。
同时会保留 `allowedCommandsPinnedCount`，方便确认当前有多少条命令是 digest pinning。

### `GET /api/device/runtime/recovery`

读取当前本机可见的 recovery bundle 摘要列表。

可选参数：

- `limit=8`

返回值会包含：

- `bundles`
- `counts.total`
- `recoveryDir`

### `POST /api/device/runtime/recovery`

导出当前本地参考层的恢复包。

这个恢复包会：

- 用 passphrase 包装本地 store key
- 可选携带当前加密账本 envelope
- 可选保存到 `data/recovery-bundles`

`passphrase` 是必填项。没有 recovery passphrase 时接口会拒绝导出，因为 agent-passport 不做中心化账号找回；没有 recovery bundle + recovery passphrase，就不能恢复原 Agent。

常用字段：

- `passphrase`
- `note`
- `includeLedgerEnvelope`
- `saveToFile`
- `returnBundle`
- `dryRun`

### `POST /api/device/runtime/recovery/import`

导入一个恢复包，恢复本地 store key，必要时恢复账本 envelope。

常用字段：

- `passphrase`
- `bundle`
- `bundleJson`
- `bundlePath`
- `overwrite`
- `restoreLedger`
- `importStoreKeyTo=auto|keychain|file`
- `removeLegacyFile`
- `dryRun`

默认 `auto` 会优先把恢复出的 store key 导回系统 Keychain；只有 Keychain 不可用时才回退到本地文件。
`dryRun` 和正式导入现在共享同一套冲突检查：只要目标机器上已经有 store key 或 ledger envelope，且你没有显式传 `overwrite=true`，导入就会直接拒绝，不再出现“dry-run 能过、正式导入才覆盖”的分叉语义。

### `GET /api/device/runtime/recovery/rehearsals`

读取恢复演练记录。

可选参数：

- `limit=8`

返回值会包含：

- `rehearsals`
- `counts.total`
- `counts.byStatus`

这条链用于证明：

- recovery bundle 可解封
- 当前账本 envelope 可解密
- chainId / lastEventHash 能和当前本地 store 对齐

### `POST /api/device/runtime/recovery/verify`

对某个 recovery bundle 做一次显式恢复演练，不真正导入密钥。

常用字段：

- `passphrase`
- `bundle`
- `bundleJson`
- `bundlePath`
- `dryRun`
- `persist`

当前会返回：

- `rehearsal.status=passed|partial|failed`
- `rehearsal.matchSummary`
- `rehearsal.bundleLedgerSummary`
- `rehearsal.currentLedgerSummary`

### `GET /api/device/setup`

读取当前设备是否已经完成“单机单 Agent”冷启动。

返回值会包含：

- `setupComplete`
- `missingRequiredCodes`
- `residentAgentId`
- `residentDidMethod`
- `checks`
- `deviceRuntime`
- `setupPolicy`
- `bootstrapGate`
- `localReasonerDiagnostics`
- `formalRecoveryFlow`
- `automaticRecoveryReadiness`
- `recoveryBundles`
- `recoveryRehearsals`
- `latestPassedRecoveryRehearsal`
- `latestPassedRecoveryRehearsalAgeHours`
- `setupPackages`

这条接口会检查至少这些前置条件：

- resident agent 是否已绑定
- task snapshot / profile 是否已就绪
- local reasoner 是否已配置
- local reasoner 是否真实可达
- recovery export 是否可用

同时会返回：

- `formalRecoveryFlow.runbook`
- `formalRecoveryFlow.operationalCadence`
- `automaticRecoveryReadiness`

### `POST /api/device/setup`

执行一次设备初始化或 dry-run 预演。

正式创建默认启用 `requireRecoveryBackup=true`。也就是说，普通产品创建流程必须先提供 `recoveryPassphrase`，并在同一轮完成 recovery bundle 导出、recovery rehearsal 通过、device setup package 导出，才会返回创建闭环结果。缺少恢复口令时接口会拒绝：

> agent-passport 采用用户自持恢复资料。创建 Passport 前必须设置恢复口令并导出恢复资料。恢复口令和恢复包丢失后无法恢复原 Agent。

旧维护脚本如确实只想做运行态配置，可显式传 `requireRecoveryBackup=false`；普通用户入口不应关闭这个开关。`dryRun=true` 仍保持预览语义，不会为了备份闭环创建账本、store key 或恢复目录。

常用字段：

- `residentAgentId`
- `residentDidMethod`
- `displayName`
- `role`
- `title`
- `currentGoal`
- `currentPlan`
- `nextAction`
- `recoveryPassphrase`
- `requireRecoveryBackup`
- `dryRun`

适合在一台新机器第一次承载 resident agent 时执行。

创建 Agent / 首次 setup 的产品闭环是：

1. 填写 Agent 信息
2. 设置 recovery passphrase
3. 导出 recovery bundle
4. 验证 recovery bundle 可被 recovery passphrase 解开
5. 导出 setup package
6. 用户确认已保存 recovery bundle、setup package、recovery passphrase，并理解丢失后无法恢复原 Agent

Agent 创建后会进入可查询的 `recoveryBackup.status=backup_pending`。正式 setup 导出 recovery bundle、通过 rehearsal 并导出 setup package 后，只会推进到 `backup_artifacts_ready`；用户完成四项确认后，前端再提交 `/api/agents/:agentId/recovery-backup/confirm`，后端才会标记 `backup_completed`。如果页面关闭或用户没完成四项确认，前端还会保存一个非秘密的“未完成备份 / 不建议继续使用”本地兜底标记，用来提醒用户这个 Agent 还不能当成安全创建完成；后端状态和本地标记都不包含 recovery passphrase、store key、signing key 或管理令牌。

换设备导入时，recovery bundle 会恢复原 Agent、长期记忆和本地加密资料；setup package 会恢复设备运行配置和 resident binding。源设备上的“用户已确认保存”不会被目标设备凭空继承，目标设备仍应重新完成自己的恢复资料备份确认。

### `GET /api/device/setup/package`

预览当前这台机器的 `device setup package`。

这不是密钥导出，也不包含 recovery passphrase。它只会打包：

- resident agent / did method
- 当前 device runtime 配置
- 当前 setup 状态与缺失项
- recovery / rehearsal 摘要
- 当前设备上已保存的 local reasoner profiles 摘要

适合用来：

- 迁机前确认当前单机配置
- 重装前保存一份“不带秘密的 setup manifest”
- 在另一台机器上 dry-run 预演导入

可选查询参数：

- `includeLocalReasonerProfiles=false`
- `localReasonerProfileId=<profileId>`
- `localReasonerProfileIds=<profileId>,<profileId>`
- `localReasonerProfileLimit=1`

### `POST /api/device/setup/package`

导出一个显式的 `device setup package`。

常用字段：

- `note`
- `saveToFile`
- `returnPackage`
- `dryRun`
- `includeLocalReasonerProfiles`
- `localReasonerProfileIds`
- `localReasonerProfileLimit`

`localReasonerProfileIds` / `localReasonerProfileLimit` 用于有界打包 local reasoner profiles。默认不传时保持全量兼容；在 smoke、演练或只需要当前 profile 的迁移预演里，建议只指定本轮确认过的 profile，避免历史 profiles 堆积导致 setup package 越来越慢。

导出的 package 不包含：

- store key
- signing key
- 管理令牌
- recovery passphrase

### `GET /api/device/setup/packages`

列出本机当前可见的 `device setup package` 摘要。

可选参数：

- `limit=5`

返回值会包含：

- `packages`
- `counts.total`
- `packageDir`

### `GET /api/device/setup/packages/:packageId`

读取某一份已保存的 `device setup package`。

适合：

- 重装前确认某一份 package 的 resident/runtime 内容
- 导入前先做人工核对
- smoke / 运维链路里确认最近一次导出是否正确

### `POST /api/device/setup/packages/:packageId/delete`

删除一份已保存的 `device setup package`。

常用字段：

- `dryRun`

### `POST /api/device/setup/packages`

按保留策略清理一批已保存的 `device setup package`。

常用字段：

- `keepLatest`
- `residentAgentId`
- `noteIncludes`
- `dryRun`

适合：

- 保留最近 N 份 setup package
- 只清理某个 resident agent 的历史 package
- 用 `noteIncludes` 先过滤 smoke / 运维批次，避免误删别的 package

### `POST /api/device/setup/package/import`

导入一个 `device setup package`，把 resident/runtime 配置重新落到当前设备。

常用字段：

- `package`
- `packageJson`
- `packagePath`
- `allowResidentRebind`
- `dryRun`
- `importLocalReasonerProfiles`

这个导入链默认只恢复：

- resident 绑定
- device runtime policy
- local reasoner / retrieval / sandbox 配置
- 可选的 local reasoner profiles

它不会直接恢复：

- 加密账本
- store key
- signing key
- 管理令牌

### `GET /api/device/runtime/local-reasoner`

检查当前本机 local reasoner 的真实状态。

返回值会包含：

- `deviceRuntime`
- `diagnostics.provider`
- `diagnostics.configured`
- `diagnostics.reachable`
- `diagnostics.status`

其中：

- `local_command` 会检查 command / cwd / 首个脚本参数是否存在
- `ollama_local` 会探测本机 Ollama 的 `/api/tags`，并返回当前模型列表

### `GET /api/device/runtime/local-reasoner/catalog`

返回当前单机可见的本地 reasoner 目录。

当前会列出：

- `local_command`
- `ollama_local`
- `local_mock`

每个 provider 都会带：

- `selected`
- `config`
- `selection`
- `lastProbe`
- `lastWarm`
- `diagnostics`
- `availableModels`

### `POST /api/device/runtime/local-reasoner/probe`

对一组临时 local reasoner 配置执行探针，不直接改写当前 runtime。

常用字段：

- `provider`
- `command`
- `args`
- `cwd`
- `baseUrl`
- `model`

### `POST /api/device/runtime/local-reasoner/select`

把当前 device runtime 的本地 reasoner 切到指定 provider，并把选择结果持久化。

常用字段：

- `provider`
- `enabled`
- `command`
- `args`
- `cwd`
- `baseUrl`
- `model`
- `dryRun`

这个接口适合把“探针通过的配置”正式切成当前 resident runtime 的选中 provider。

### `POST /api/device/runtime/local-reasoner/prewarm`

对当前选中的本地 reasoner 执行一次真实预热，并把 `lastProbe / lastWarm` 写回 runtime。

常用字段：

- `provider`
- `baseUrl`
- `model`
- `dryRun`

预热不是只看配置字段，而是会真实走一轮本地 candidate 生成链，验证：

- provider 是否可达
- 当前模型是否可用
- 本地 Runtime 是否能拿到候选回复

### `GET /api/device/runtime/local-reasoner/profiles`

列出当前设备上已保存的 local reasoner profile 摘要。

适合：

- 查看 resident runtime 当前可复用的本地推理器配置快照
- 给不同机器或不同离线模式准备 profile 目录

返回摘要里现在还会带：

- `health.status`
- `health.restorable`
- `health.lastHealthyAt`

### `POST /api/device/runtime/local-reasoner/profiles`

把当前 local reasoner 配置保存成一个可复用 profile。

常用字段：

- `profileId`
- `label`
- `note`
- `source`
- `dryRun`

### `GET /api/device/runtime/local-reasoner/profiles/:profileId`

读取单个 local reasoner profile 的摘要和配置详情。

如果通过 `read_session` 读取这个接口，`command / cwd / args` 会被 redaction，不会直接暴露本地命令链。

### `POST /api/device/runtime/local-reasoner/profiles/:profileId/activate`

把某个已保存的 local reasoner profile 重新激活到当前 device runtime。

适合：

- 在 `local_command / ollama_local / local_mock` 之间快速切换
- 把一次 probe 成功的配置固化成 profile 再反复启用

### `POST /api/device/runtime/local-reasoner/profiles/:profileId/delete`

删除一个已保存的 local reasoner profile。

### `GET /api/device/runtime/local-reasoner/restore-candidates`

列出当前设备上可用于恢复 local reasoner 的候选 profile。

它会按下面的优先级排序：

- 是否可恢复
- 最近一次健康时间
- 最近激活时间
- 使用次数
- 最近更新时间

返回字段里会包含：

- `recommended`
- `health.status`
- `health.restorable`
- `health.lastHealthyAt`

### `POST /api/device/runtime/local-reasoner/restore`

把当前 device runtime 的 local reasoner 恢复到某个可用 profile。

常用字段：

- `profileId`
- `prewarm`
- `dryRun`

如果不传 `profileId`，系统会优先挑选当前最推荐的 restore candidate。

默认恢复链会：

- 重新激活对应 profile
- 可选执行一次 `prewarm`
- 把恢复结果重新写回当前 runtime

### `POST /api/agents/:id/runtime/actions`

在当前 runtime 的受限动作执行层里执行一个受限动作。

说明：代码字段仍沿用 `sandbox*` 命名；当前实现是“受限执行层 + broker / worker 隔离”，并且在 macOS 上会优先给 broker 落 `sandbox-exec`，但还不是完整容器级沙箱。

当前支持的能力：

- `runtime_search`
- `filesystem_list`
- `filesystem_read`
- `conversation_minute_write`

额外约束：

- `process_exec` 输入正文会受到 `maxProcessInputBytes` 预算限制
- `local_command` reasoner 也会走独立的 worker 输入预算
- 如果 `local_command` 输入超限，会显式失败，不会把 JSON 静默截断后继续执行
- `network_external`
- `process_exec`

执行前仍然会经过：

- resident gate
- bootstrap gate
- risk-tier negotiation
- capability allowlist / filesystem allowlist

补充说明：

- 就算能力、命令、URL 只写在 `sandboxAction` 里，协商层和真实执行层也会按同一套 allowlist / disable policy 重复校验
- 也就是说，`sandboxAction` 不是绕过 negotiation 的另一条入口，只是执行参数的结构化载体

常用字段：

- `interactionMode=command`
- `executionMode=execute`
- `confirmExecution=true`
- `requestedAction`
- `requestedCapability`
- `requestedActionType`
- `targetResource`
- `sandboxAction`

返回值会包含：

- `status`
- `negotiation`
- `sandboxExecution.capability`
- `sandboxExecution.executionBackend`
- `sandboxExecution.output`
- `sandboxAudit`

其中：

- `runtime_search / conversation_minute_write` 当前走 `in_process`
- `filesystem_list / filesystem_read` 当前走 `subprocess worker`
- `network_external / process_exec` 已接入 worker backend，但默认仍受风险分级、allowlist 和关闭状态约束
- `network_external` 只允许 `http/https`
- `network_external` 默认拒绝 HTTP 重定向，避免 allowlisted host 被重定向逃逸
- host allowlist 现在走精确 hostname 匹配，不再做模糊匹配
- `process_exec` 默认要求绝对路径命令，并受 `maxProcessArgs / maxProcessArgBytes` 预算约束
- `process_exec` allowlist 现在支持 `绝对路径|sha256=<digest>` 的 digest pinning
- 如果 allowlisted 命令配置了 digest，实际执行前会对真实二进制做 `sha256` 校验，不匹配就直接拒绝
- `process_exec` worker 会在隔离的 `HOME/TMPDIR` 下运行，不再继承主进程环境变量

### `GET /api/agents/:id/runtime/actions`

列出当前 Agent 最近的受限动作审计历史。

说明：返回字段仍沿用 `sandbox action` 命名，兼容现有接口。

常用查询参数：

- `limit`
- `capability`
- `status`
- `didMethod`

返回值会包含：

- `audits`
- `counts.total`
- `counts.byCapability`
- `counts.byStatus`

适合：

- 查看 resident runtime 最近做过哪些受限动作
- 区分哪些 action 成功、哪些被拒绝或失败
- 配合 `runtime_search / filesystem_* / process_exec / network_external` 做本地审计

如果通过 `read_session` 读取这个接口：

- `input` 会做字段级 redaction
- 文件路径、命令路径、URL、stdout/stderr、preview 等敏感字段不会直接透出
- `runtime_search` 和 `conversation_minute_write` 的输出也会继续走各自的 redaction 规则

### `GET /api/protocol`

读取当前 `agent-passport` 的机器可读产品 / 接口元描述。

返回值会包含：

- 当前协议名、版本、链 ID
- 当前第一阶段产品定位与 MVP 叙事
- 当前人类可读文档索引
- 当前安全架构原则与已知缺口
- 下一阶段实施清单
- 当前启用的 DID method、未来计划 method、可解析 / 可签发列表与 migration 状态
- DID / VC / proof / status / evidence 的 canonical type
- 对旧 `OpenNeed*` 类型名的兼容别名
- 当前本地账本里的 agents / credentials / comparison audits 数量

这个接口主要给 agent 自己读，让它先知道“当前产品和接口怎么组织”，再去调用其它身份、比较和证据接口。

### `GET /api/roadmap`

读取精简后的产品定位、当前安全架构和下一阶段实施清单。

这个接口适合：

- 给 agent 自己读下一阶段目标
- 给前端页面或运行态面板展示当前 MVP 定位
- 给后续自动化任务读取安全与实施优先级

### `POST /api/agents`

创建新的 Agent 身份。

```json
{
  "displayName": "agent-passport Agents",
  "role": "shared-identity",
  "controller": "Kane",
  "signers": ["Kane", "Alice"],
  "multisigThreshold": 2,
  "walletAddress": "0x1234567890abcdef1234567890abcdef12345678",
  "initialCredits": 100
}
```

### `POST /api/agents/:id/fork`

从已有 Agent 分叉出新的身份。

```json
{
  "displayName": "agent-passport Agents v2",
  "role": "forked-agent",
  "controller": "agent-passport Agents",
  "signers": ["Kane", "Alice"],
  "multisigThreshold": 2,
  "authorizedBy": "source-agent",
  "approvals": ["Kane", "Alice"]
}
```

### `PATCH /api/agents/:id/policy`

更新某个 Agent 的签名策略。

```json
{
  "signers": ["Kane", "Alice", "Bob"],
  "multisigThreshold": 2,
  "walletAddress": "0x1234567890abcdef1234567890abcdef12345678"
}
```

### `POST /api/agents/:id/grants`

给某个 Agent 授权资源。

```json
{
  "fromAgentId": "agent_xxx",
  "amount": 20,
  "assetType": "credits",
  "reason": "bootstrap",
  "authorizedBy": "agent_xxx",
  "approvals": ["agent_xxx"]
}
```

### `GET /api/agents/:id/context`

读取一个 Agent 的共享中枢上下文，包含身份、资产、窗口、记忆、消息、授权提案和该身份域下的状态列表摘要。
返回值里会同时带上 `statusList` 和 `statusLists`，前者是当前 Agent 对应的默认状态列表，后者是注册表里的状态列表集合。
现在还会带上 `credentialMethodCoverage`，用于说明这个 Agent 相关证据在 `openneed` / `agentpassport` 两条 DID method 下的覆盖情况。
其中 `credentialMethodCoverage.repairableSubjects` 会直接列出当前可以自动补齐缺失 method 的证据对象。
现在也会带上最近的 `migrationRepairs` 和 `counts.migrationRepairs`，方便 agent 不额外查 repair 接口，也能直接在共享中枢里看到最近修复历史。

如果通过 `read_session` 读取，这个接口现在默认返回 redacted 观察视图：

- `memories / inbox / outbox` 只保留元信息，不回正文
- `runtime.taskSnapshot` 的 `objective / nextAction / currentPlan` 会被置空
- `credentials` 里的 `proofValue` 会被置空
- `memoryLayers` 会收敛成计数与字段键集合，而不是整层内容回放

可选参数：

- `didMethod=agentpassport`
- `didMethod=openneed` 只用于显式兼容历史 DID 视角

传 `didMethod=agentpassport` 时，共享中枢里返回的 `identity.did`、`didDocument` 和默认状态列表会切到 `did:agentpassport:` 视角。

现在这个 context 还会返回 `memoryLayers`，把 本地参考层里的五层记忆一起暴露出来：

- `ledger`
  说明：基础参考层，来自 ledger / DID / 钱包 / 授权 / 分叉 / 承诺
- `profile`
  说明：稳定身份层，记录名字、角色、长期目标、稳定偏好
- `episodic`
  说明：阶段经历层，记录任务结果、关系变化、阶段事件
- `semantic`
  说明：语义抽象层，记录从多次事件里沉淀出的 schema 和稳定规律
- `working`
  说明：工作上下文层，记录当前任务临时上下文、recent turns、tool results

这一步的核心原则是：

`聊天记录不是身份；本地参考层才是身份。`

当前 context / runtime 相关返回值里还会带：

- `deviceRuntime`
- `residentGate`

其中 `residentGate` 会明确告诉你：

- 当前 Agent 是不是这台机器的 resident agent
- 当前运行是否被 resident 锁阻止
- 当前本地模式是否允许联网增强

### `POST /api/agents/:id/memories`

给某个 Agent 写入一条共享记忆。

### `GET /api/agents/:id/memories`

读取某个 Agent 的记忆列表。

### `POST /api/agents/:id/messages`

把一条消息路由到某个 Agent 的共享收件箱。

默认只信任目标 Agent 路径参数；`fromAgentId` / `fromWindowId` 不再作为 HTTP 请求里的可信 sender 归因来源。

### `GET /api/agents/:id/messages`

读取某个 Agent 的收件箱 / 发件箱。

### `GET /api/agents/:id/passport-memory`

读取 本地参考层里的分层记忆。

可选参数：

- `layer=profile|episodic|semantic|working|ledger`
- `kind=role|result|commitment|...`
- `query=...`
- `limit=20`

### `POST /api/agents/:id/passport-memory`

直接写入一条结构化本地记忆记录。

```json
{
  "layer": "profile",
  "kind": "role",
  "summary": "CEO",
  "content": "CEO",
  "payload": {
    "field": "role",
    "value": "CEO"
  },
  "tags": ["identity"],
  "sourceWindowId": "window_demo_1",
  "recordedByAgentId": "agent_main",
  "recordedByWindowId": "window_demo_1"
}
```

### `POST /api/agents/:id/memory-compactor`

把多轮聊天压缩成结构化 memory。

注意：

- 它不是单纯摘要聊天
- 它会把对话里的稳定身份、阶段结果、当前任务、承诺等信息写回本地参考层
- 摘要只作为辅助，结构化本地记忆记录才是本地参考层

```json
{
  "turns": [
    { "role": "user", "content": "名字：沈知远" },
    { "role": "assistant", "content": "角色：CEO" },
    { "role": "user", "content": "当前任务：推进 context builder" },
    { "role": "assistant", "content": "承诺：本地参考层才是本地参考源" }
  ],
  "writeConversationTurns": true,
  "sourceWindowId": "window_demo_1",
  "recordedByAgentId": "agent_main",
  "recordedByWindowId": "window_demo_1"
}
```

### `POST /api/agents/:id/runtime/bootstrap`

给一个 Agent 建最小冷启动包。

这个入口会尽量复用现有 store 结构，而不是另起一套：

- 写 `profile memory`
- 写最小 `working memory`
- 可选写默认 ledger commitment
- 创建或更新 `task snapshot`
- 生成新的 `contextBuilder / rehydrate / sessionState`
- 给 `task snapshot` 写入默认 runtime budget
- 可选把当前设备认领为这个 Agent 的 resident machine

推荐在 agent 第一次进入 runner 前先走一次。

```json
{
  "displayName": "沈知远",
  "role": "CEO",
  "longTermGoal": "让 agent-passport 建立在可恢复、可审计的记忆稳态运行时之上",
  "stablePreferences": ["冷启动优先", "先验证再写回"],
  "title": "agent-passport 启动准备",
  "currentGoal": "建立最小冷启动包，避免身份漂移",
  "currentPlan": ["写 profile", "写 snapshot", "验证 runner"],
  "nextAction": "执行 runtime integrity 自检",
  "constraints": ["LLM 不是本地参考源", "高风险动作需要 grounding"],
  "successCriteria": ["snapshot 可用", "profile 就绪"],
  "maxConversationTurns": 12,
  "maxContextChars": 16000,
  "maxRecentConversationTurns": 6,
  "maxToolResults": 6,
  "maxQueryIterations": 4,
  "createDefaultCommitment": true,
  "claimResidentAgent": true,
  "dryRun": false
}
```

如果只是想看“会写什么”而不真正落盘，可以传：

- `dryRun=true`

### `GET /api/agents/:id/runtime/minutes`

读取某个 Agent 的本地对话纪要列表。

可选参数：

- `limit=8`

### `POST /api/agents/:id/runtime/minutes`

写入一条本地对话纪要。

这层的目标不是“把整段聊天塞回 prompt”，而是把阶段性讨论结果落成可检索的本地纪要，后续给 `runtime search / rehydrate / context builder` 复用。

```json
{
  "title": "4 月 3 日离线运行讨论",
  "summary": "确认当前本地参考层默认只绑定一个 resident agent，忘了先查本地纪要再恢复。",
  "transcript": "结论：不要从聊天历史猜身份，要从本地参考层和本地纪要恢复。",
  "highlights": ["single resident agent", "local search", "rehydrate"],
  "actionItems": ["补本地模型 provider", "补 transcript model"],
  "tags": ["minutes", "offline", "runtime"],
  "sourceWindowId": "window_demo_1",
  "recordedByAgentId": "agent_main",
  "recordedByWindowId": "window_demo_1"
}
```

### `GET /api/agents/:id/transcript`

读取当前 Agent 的结构化 transcript。

可选参数：

- `family=runtime|conversation|message|checkpoint`
- `limit=20`

返回值会包含：

- `transcript.entryCount`
- `transcript.entries`
- `transcript.familyCounts`
- `transcript.entryTypeCounts`
- `transcript.messageBlocks`
- `transcript.families`
- `counts.byEntryType`

这层和 conversation minutes 不同：

- minutes 是阶段性纪要
- transcript 是 runtime 真实事件轨

当前 transcript 会记录：

- `user_turn`
- `assistant_turn`
- `tool_result`
- `verification`
- `checkpoint`
- `compact_boundary`
- `message_inbox`
- `message_outbox`

### `GET /api/agents/:id/runtime/search`

在本地参考层里搜索当前 Agent 的可恢复知识。

当前会检索这些来源：

- `conversation_minute`
- `task_snapshot`
- `decision`
- `evidence`
- `passport_memory`
- `compact_boundary`
- `external_cold_memory`，但只会在显式开启 `retrievalPolicy.externalColdMemory.enabled=true` 后出现

可选参数：

- `didMethod=agentpassport|openneed`
- `query=...`
- `sourceType=conversation_minute|task_snapshot|decision|evidence|passport_memory|compact_boundary|external_cold_memory`
- `limit=8`

默认不混入外部冷记忆；只有显式传 `sourceType=external_cold_memory` 时，runtime search 才会返回 sidecar 候选。

返回值里会包含：

- `hits`
- `counts.bySource`
- `suggestedResumeBoundaryId`
- `retrieval.strategy=local_first_non_vector`
- `retrieval.scorer=lexical_v1`
- `retrieval.vectorUsed=false`
- `retrieval.externalColdMemoryEnabled`
- `retrieval.externalColdMemoryProvider`
- `retrieval.externalColdMemoryHitCount`

如果启用了 `external_cold_memory`：

- 它只是只读候选线索
- 不覆盖 `ledger/profile/runtime` 本地参考层
- `context builder` 会单独放进 `externalColdMemory`

如果通过 `read_session` 读取，`hits` 仍会保留来源类型和分数，但自由文本、URI 和原始 payload 会被 redacted。

如果外部冷记忆检索本身报错，`read_session` 也不会直接返回原始错误文本，而是改成：

- `retrieval.externalColdMemoryError=null`
- `retrieval.externalColdMemoryErrorRedacted=true`

### `GET /api/agents/:id/runtime/rehydrate`

读取当前 agent 的最小 rehydrate 包。

默认返回当前运行态下的重建包；如果要从某个 compact boundary 后继续恢复，可以传：

- `resumeFromCompactBoundaryId=cbnd_xxx`

返回值现在会额外包含：

- `resumeBoundary`
- `sources.resumeFromCompactBoundaryId`
- `deviceRuntime`
- `residentGate`
- `localKnowledgeHits`
- `externalColdMemoryHits`

如果通过 `read_session` 读取：

- `prompt` 会被置空
- `localKnowledgeHits` 的自由文本与 URI 会被 redacted
- `externalColdMemoryHits` 的自由文本与来源细节也会被 redacted
- `recentMemories / recentInbox / recentOutbox` 的正文会被 redacted
- `recentCredentials` 的 `proofValue` 会被 redacted

### `POST /api/agents/:id/context-builder`

按槽位重建上下文，而不是拼接整段聊天历史。

当前会组装这些槽位：

- `systemRules`
- `currentGoal`
- `identitySnapshot`
- `relevantLedgerFacts`
- `localKnowledgeHits`
- `externalColdMemory`
- `resumeBoundary`
- `relevantProfileMemories`
- `relevantEpisodicMemories`
- `queryBudget`
- `recentConversationTurns`
- `toolResults`

这里要注意：

- `localKnowledgeHits` 只代表本地真源命中
- `externalColdMemory` 才代表 `mempalace` 这类外部冷记忆侧车命中
- 如果当前回复要交给远端 `http/openai_compatible` reasoner，`externalColdMemory` 会只保留 `provider/hitCount/candidateOnly/hint`
- 同时会显式带上 `redactedForRemoteReasoner=true`，并从 `compiledPrompt` 里去掉 `EXTERNAL COLD MEMORY CANDIDATES / QUERY BUDGET`
- `http` provider 的出站 `payload` 不再保留空的 `recentConversationTurns / toolResults`

```json
{
  "currentGoal": "继续推进 context builder",
  "query": "identity snapshot response-check",
  "resumeFromCompactBoundaryId": "cbnd_xxx",
  "recentConversationTurns": [
    { "role": "user", "content": "不要从整段历史里猜身份" }
  ],
  "toolResults": [
    { "tool": "runtime", "result": "rehydrate ready" }
  ]
}
```

### `POST /api/agents/:id/response-verify`

在模型回复后，用本地参考层 做事实校验。

当前最小校验会检查：

- 有没有说错 `agent_id`
- 有没有说错 `parent / fork` 关系
- 有没有说错钱包地址
- 有没有和授权阈值冲突
- 有没有和 profile memory 的名字 / 角色冲突

```json
{
  "responseText": "agent_id: agent_treasury",
  "claims": {
    "agentId": "agent_treasury",
    "role": "产品总监"
  }
}
```

公开 HTTP 路由会忽略请求体里自带的 `contextBuilder` 快照，统一回到服务器本地参考层重算，不接受客户端伪造 `memoryLayers / sourceMonitoring / identitySnapshot` 来影响校验结论。

### `POST /api/agents/:id/runtime/drift-check`

按当前任务快照和运行策略，判断这一轮上下文有没有漂移到该 `rehydrate / checkpoint / human review`。

请求体常用字段：

- `currentGoal`
- `workingSummary`
- `nextAction`
- `turnCount`
- `estimatedContextChars`
- `estimatedContextTokens`
- `recentConversationTurnCount`
- `toolResultCount`
- `queryIteration`
- `referencedDecisionIds`
- `referencedEvidenceRefIds`

公开 HTTP 路由不会信任客户端自带的 `runtimeSnapshot` / `taskSnapshot` / `runtimePolicy`，会始终以服务器当前 ledger/runtime 真值重算，避免外部请求通过伪造阈值把 `requiresRehydrate` 压成 `false`。

### `GET /api/agents/:id/runner`

读取最近的 runner 运行记录。

可选参数：

- `limit=10`
- `status=prepared|completed|blocked|rehydrate_required|needs_human_review|bootstrap_required|resident_locked|negotiation_required`

### `POST /api/agents/:id/runner`

执行一轮最小 runner 闭环。

当前流程是：

1. 先按本地参考层重建 context
2. 如果 resident agent 绑定策略不满足，则直接返回 `resident_locked`
3. 如果 bootstrap gate 不满足，则直接返回 `bootstrap_required`
4. 根据本地运行策略选择 reasoner；`local_only` 模式会优先落到离线 provider
5. 如果是命令型输入，先走 negotiation loop，必要时返回 `negotiation_required`
6. 再做 drift check
7. 如果拿到了候选回复，就做回复校验
8. 如果校验通过，再把这一轮 conversation / tool results compact 回结构化 memory
9. working memory 超阈值时自动做 checkpoint / rollover
10. 最后生成一条运行记录

```json
{
  "currentGoal": "继续推进 context builder",
  "query": "identity snapshot response-check",
  "resumeFromCompactBoundaryId": "cbnd_xxx",
  "userTurn": "请确认你是谁",
  "interactionMode": "command",
  "requestedAction": "整理本地对话纪要，并更新 working memory",
  "executionMode": "execute",
  "confirmExecution": false,
  "allowOnlineReasoner": false,
  "recentConversationTurns": [
    { "role": "assistant", "content": "应当先回本地参考层 取本地资料" }
  ],
  "toolResults": [
    { "tool": "runtime", "result": "rehydrate ready" }
  ],
  "reasonerProvider": "local_mock",
  "reasonerUrl": "http://127.0.0.1:3000",
  "reasonerModel": "gpt-4.1-mini",
  "queryIteration": 2,
  "turnCount": 3,
  "estimatedContextChars": 1600,
  "workingCheckpointThreshold": 12,
  "workingRetainCount": 6,
  "autoCompact": true,
  "storeToolResults": true,
  "persistRun": true,
  "sourceWindowId": "window_demo_1",
  "recordedByAgentId": "agent_main",
  "recordedByWindowId": "window_demo_1"
}
```

返回值里会包含：

- `run`
- `contextBuilder`
- `reasoner`
- `reasonerPlan`
- `bootstrapGate`
- `residentGate`
- `negotiation`
- `queryState`
- `driftCheck`
- `verification`
- `compaction`
- `checkpoint`
- `compactBoundary`
- `sessionState`

如果你传了 `resumeFromCompactBoundaryId`，返回的 `run` 也会带：

- `resumeBoundaryId`

如果你已经有人工写好的候选回复，也可以继续传 `candidateResponse`，此时 runner 会自动回退到 `passthrough` 模式。

当前 reasoner provider 支持：

- `passthrough`
- `mock`
- `local_mock`
- `local_command`
- `ollama_local`
- `http`
- `openai_compatible`

其中：

- `local_mock` 代表本地离线优先的最小 provider，适合单机单 Agent 的第一阶段
- `local_command` 代表把上下文组装后交给本机命令执行器，适合离线 fixture、本地脚本和后续自托管推理器
- `ollama_local` 会向本机 Ollama 的 `/api/chat` 发请求，适合真正接入离线本地模型
- `openai_compatible` 会向兼容 `/v1/chat/completions` 的端点发起真实模型调用，适合接本地网关或兼容服务
- 如果当前设备是 `local_only`，而你又请求了在线 provider，runner 会自动降级到离线 provider，而不是偷偷联网

这个接口是当前最接近“默认执行路径”的入口，后面如果要把外部 LLM 真正接进来，最自然的做法就是把模型调用挂在这个 runner 的前后。

### `GET /api/agents/:id/session-state`

读取当前 agent 的显式运行时状态。

返回值会包含：

- 当前 DID / didMethod
- `currentGoal`
- `currentTaskSnapshotId`
- `latestRunId / latestRunStatus`
- `latestCompactBoundaryId`
- `latestResumeBoundaryId`
- `latestQueryStateId`
- `latestNegotiationId / latestNegotiationDecision`
- `queryState`
- `tokenBudgetState`
- `residentAgentId`
- `residentLockRequired`
- `localMode`
- `memoryCounts`

### `GET /api/agents/:id/query-states`

读取这个 agent 最近的显式 `QueryState` 历史。

每条 query state 会带：

- `queryStateId`
- `status`
- `currentGoal`
- `currentIteration / maxQueryIterations / remainingIterations`
- `resumeBoundaryId`
- `budget`
- `flags`
- `recommendedActions`

### `GET /api/agents/:id/compact-boundaries`

读取这个 agent 最近的 compact boundaries。

compact boundary 不是普通 summary，它代表一次明确的压缩恢复边界，里面会带：

- `compactBoundaryId`
- `runId`
- `previousCompactBoundaryId`
- `resumedFromCompactBoundaryId`
- `chainRootCompactBoundaryId`
- `resumeDepth`
- `lineageCompactBoundaryIds`
- `checkpointMemoryId`
- `contextHash`
- `archivedMemoryIds`
- `retainedMemoryIds`

### `GET /api/agents/:id/verification-runs`

读取这个 agent 最近的 runtime integrity 自检记录。

可选参数：

- `limit=10`
- `status=passed|failed|partial`

### `POST /api/agents/:id/verification-runs`

执行一轮 runtime integrity verification 自检。

这个入口的定位不是替代 runner，也不是外部独立审计，而是检查当前 runtime 是否具备：

- 稳定 identity snapshot
- task snapshot / profile bootstrap
- adversarial probe 拦截能力
- compact boundary 恢复点
- run 记录可回放性

```json
{
  "currentGoal": "检查当前 runtime 是否具备冷启动条件",
  "query": "runtime integrity compact boundary bootstrap",
  "mode": "runtime_integrity",
  "persistRun": true,
  "sourceWindowId": "window_demo_1"
}
```

公开 HTTP 路由会固定使用服务器默认的 adversarial identity probe，不接受请求体覆写 `adversarialResponseText` / `adversarialClaims` 来影响 verification 结论。

返回值里会包含：

- `verificationRun`
- `sessionState`
- `contextBuilder`
- `adversarialVerification`

### `GET /api/agents/:id/authorizations`

读取某个 Agent 相关的授权提案。

返回的提案视图现在会带上 `signatures` / `signatureCount` / `latestSignatureAt` / `executionReceipt` / `timeline`，方便直接看谁签过、什么时候执行、执行结果是什么，以及整条提案路径。

### `GET /api/agents/:id/did`

读取该 Agent 的 DID 文档。

新的 DID 文档会公开一把确定性的 `#signing-1` 本地签名键，并保留钱包地址型 verification methods，方便后续接真正的 DID key 签名和 VC proof。

可选参数：

- `method=openneed`
- `method=agentpassport`

默认返回当前激活 method 的 DID 文档，同时响应里会带 `didAliases`，表示同一个 Agent 的 DID 别名集合。

### `GET /api/agents/:id/credential`

导出该 Agent 的本地证据包。

这个返回值是一个本地自签、可在当前账本内校验的 VC 风格对象，包含 DID、钱包、控制人、多签策略、窗口、记忆、授权提案和本地账本摘要，便于后续接真正的 Verifiable Credentials。

导出时会顺手在本地证据注册表里生成或复用一条快照记录，所以它不仅能被直接校验，也会出现在 `GET /api/credentials` 的状态列表里。

可选参数：

- `didMethod=agentpassport`
- `didMethod=openneed` 只用于显式兼容历史 DID 视角
- `issueBothMethods=true`

这样可以显式指定这份 Agent 身份 VC 由哪条 DID method 签发；默认当前正式签发 method 是 `did:agentpassport`。
传 `issueBothMethods=true` 时，响应除了主 `credential` 之外，还会返回 `alternates`，把另一条 signable DID method 视角的证据一起导出。

### `GET /api/agents/resolve`

按 `agentId`、`did`、`walletAddress` 或 `windowId` 解析一个 Agent。

这个接口适合多窗口场景里从窗口反查到共享的 Agent 身份。

现在 `did:agentpassport:...` 与历史兼容的 `did:openneed:...` 都会解析到同一个本地 Agent；默认新签发走 `did:agentpassport`，旧账本里的 `did:openneed` 继续作为兼容别名可读。

### `GET /api/agents/compare`

比较两个 Agent 的身份、钱包、多签策略、状态列表注册表和上下文计数。

可选参数：

- `leftAgentId` / `rightAgentId`
- `leftDid` / `rightDid`
- `leftWalletAddress` / `rightWalletAddress`
- `leftWindowId` / `rightWindowId`
- `messageLimit`
- `memoryLimit`
- `authorizationLimit`
- `credentialLimit`
- `summaryOnly`

默认返回两侧完整上下文；传 `summaryOnly=true` 时会压缩成快照级输出，更适合 agent 快速判断。

返回结果里的 `comparison` 现在还会带上 `migrationDiff`，可以直接判断两侧在 DID method 迁移覆盖上的差异，不需要 agent 自己再拼 sibling credentials。

### `POST /api/agents/:id/migration/repair`

对某个 Agent 相关的证据迁移缺口做自动补齐。

请求体可选字段：

- `dryRun`
- `kinds`
- `subjectIds`
- `comparisonPairs`
- `didMethods`
- `limit`
- `includeComparison`
- `receiptDidMethod`
- `issueBothMethods`

典型用途：

- 先 `dryRun=true` 看当前准备补哪些缺失 method
- 再正式执行，把缺失的 `agent_identity` / `authorization_receipt` / `agent_comparison` 证据补齐

返回结果会带：

- `plan`
- `repaired`
- `skipped`
- `beforeCoverage`
- `afterCoverage`
- `repairReceipt`

这个接口现在默认只修复当前 `:id` 作为 issuer 的证据域，不会顺手去改别的 issuer 域。
公开 HTTP 路由也不会接受请求体覆写 `issuerAgentId` / `issuerDid` / `issuerDidMethod` / `issuerWalletAddress`。
正式执行时还会额外签发一条 `migration_receipt`，把这次 repair 自身沉淀成一条可校验的本地 repair 记录。
如果传 `issueBothMethods=true`，repair receipt 会同时按两条 signable DID method 签发，响应里的 `repairReceipt` 会返回主记录和 `alternates`。

适合让 agent 做“先检查，再修复，再留记录、再复核”的闭环。

### `GET /api/agents/compare/evidence`

生成一份本地可校验的 Agent 比较审计证据包。

这个接口复用 `GET /api/agents/compare` 的输入参数，并额外支持：

- `issuerDidMethod`
- `summaryOnly`
- `persist`
- `issueBothMethods`

传 `persist=true` 时，这份比较证据会进入本地证据注册表并拿到 `credentialRecord`，后续能直接出现在状态列表和审计流里。

公开 HTTP 路由会固定使用系统维护侧默认 issuer，不接受查询参数覆写 `issuerAgentId` / `issuerDid` / `issuerWalletAddress`。
如果传 `issuerDidMethod=agentpassport`，比较证据会用系统维护侧的 `did:agentpassport:` 视角重新签发，并写进对应身份域的状态列表。
如果再传 `issueBothMethods=true`，响应会保留主 `evidence`，并把另一条 DID method 视角的比较证据放进 `alternates`。

返回值里会包含 `comparison`、`comparisonDigest` 和一个 VC 风格的 `evidence.credential`，可以直接交给校验接口或 `POST /api/credentials/verify`。
现在还会带上 `repairIds` 和 `migrationRepairs`，方便 agent 直接看到这组 pair 最近做过哪些 migration repair，以及这些 repair 对应的回执聚合视图。

### `GET /api/agents/compare/audits`

读取同一对 Agent 的比较审计历史。

这个接口复用 `GET /api/agents/compare` 的定位参数，并额外支持：

- `issuerAgentId`
- `issuerDid`
- `issuerDidMethod`
- `status`
- `limit`

返回结果会带上这对 Agent 的 `pair` 摘要、匹配到的 `credentials`、聚合后的 `counts`，以及最新一条 `latest` 审计记录，适合 agent 回看同一组身份关系在不同时间点留下的比较证据。

传 `issuerDidMethod=agentpassport` 时，可以只看 `did:agentpassport:` 视角下的比较审计记录。

### `POST /api/agents/compare/migration/repair`

按 pair 粒度修复某一组 Agent 的比较审计证据。

请求体可选字段：

- `comparisonPairs`
- `leftAgentId` / `rightAgentId`
- `leftDid` / `rightDid`
- `leftWalletAddress` / `rightWalletAddress`
- `leftWindowId` / `rightWindowId`
- `didMethods`
- `limit`
- `dryRun`
- `receiptDidMethod`
- `issueBothMethods`

这个接口的 repair receipt 会固定落到系统维护侧默认 issuer，不接受请求体覆写 `issuerAgentId` / `issuerDid` / `issuerDidMethod` / `issuerWalletAddress`。

这个接口和 `POST /api/agents/:id/migration/repair` 的区别是：

- 前者按 Agent 自己的 issuer 域补缺口
- 这个接口按“某一对 Agent”补 compare evidence，哪怕这条 pair 以前完全没落过盘，也能从零补出来

返回结果会带：

- `comparisonPairs`
- `plan`
- `repaired`
- `skipped`
- `repairReceipt`

如果传 `issueBothMethods=true`，这次 pair repair 的回执也会同时签发 `openneed` / `agentpassport` 两个版本。

### `GET /api/migration-repairs`

按 repair 维度查看本地迁移修复历史，可选 `agentId`、`comparisonSubjectId`、`comparisonDigest`、`issuerAgentId`、`scope`、`didMethod`、`sortBy`、`sortOrder`、`limit`、`offset` 过滤。

这个接口适合 agent 直接拉 repair 列表，不需要先查询 `credentials` 再自己归并。

返回值会带：

- `repairs`
- `counts.total`
- `counts.byScope`
- `counts.byDidMethod`
- `counts.latestIssuedAt`
- `page.total`
- `page.limit`
- `page.offset`
- `page.hasMore`
- `page.latestIssuedAt`

常用筛选示例：

- `agentId=agent_main`
- `issuerAgentId=agent_treasury`
- `scope=comparison_pair`
- `didMethod=agentpassport`
- `sortBy=receiptCount&sortOrder=desc`
- `sortBy=repairedCount&sortOrder=desc`

### `GET /api/migration-repairs/:repairId`

按 `repairId` 读取一次 repair 的回执聚合视图。

返回结果外层会带一个 `repair` envelope，里面会包含：

- `repair`
- `receipts`
- `latestReceipt`
- `issuedDidMethods`
- `receiptCount`

这适合 agent 直接按 repairId 回看“这次修复到底做了什么、回执发了几条、分别是哪条 DID method”。

可选参数：

- `didMethod=agentpassport`
- `didMethod=openneed` 只用于显式兼容历史 DID 视角，不作为默认公开口径

### `GET /api/migration-repairs/:repairId/credentials`

按 `repairId` 直接查看这次 repair 关联到的 credential 记录。

这个接口会把 repair receipt 和受影响 credential 分开返回，适合 agent 直接拿 repair 的影响面，不需要再自己根据 links 回拼。

返回值会带：

- `repair`
- `receipts`
- `credentials`
- `counts.byKind`
- `counts.byDidMethod`
- `page.total`
- `page.limit`
- `page.offset`
- `page.hasMore`

可选参数：

- `didMethod`
- `sortBy=latestRepairAt`
- `sortBy=repairCount`
- `sortBy=issuedAt`
- `sortOrder=desc`
- `limit`
- `offset`

### `GET /api/migration-repairs/:repairId/timeline`

按 `repairId` 读取 repair 聚合时间线。

这个接口会直接返回 repair 聚合视图字段，并额外带上 `timeline`、`timelineCount`、`latestTimelineAt`。
时间线会把 repair 本身的汇总节点，以及该 repair 下所有 sibling receipt 的签发 / 撤销时间线合并起来，适合做审计回放。

### `GET /repair-hub`

独立的受保护修复中枢页面。

这个页面专门用于查看修复结论、影响范围、下一步、受影响 credential、状态证明和 repair 时间线。

页内 `open-main-context` 固定返回 `/`，不会再把 repair / credential / status-list 上下文反灌给首页。

支持的 query 参数包括：

- `agentId`
- `issuerAgentId`
- `scope`
- `didMethod`
- `windowId`
- `sortBy`
- `sortOrder`
- `limit`
- `offset`
- `repairId`
- `credentialId`

其中 `credentialId` 可以配合 sibling method 切换使用，让修复中枢直接落到某个并行 DID method 的 credential 视角。

公开运行态 `/` 和修复中枢现在共享 `public/ui-links.js` 里的入口命名约定，并统一由 `AgentPassportLinks` 对外暴露。修复中枢仍然保留自己的 deep-link 状态，但 `/` 本身不再承诺消费 repair / credential 上下文。

### `GET /api/offline-chat/bootstrap`

读取离线协作入口当前 runtime persona 真值。

这是公开读取接口，不要求本机 `管理令牌`。

线程历史、同步状态刷新和发送消息仍然走受保护读写。

返回值至少包含：

- `personas`
- `threads`
- `threads[group].participants`
- `threadStartup.phase_1`

其中 `group.participants` 和 `threadStartup.phase_1` 都直接来自当前 runtime persona 名单，不再依赖硬编码成员文案。

### `GET /api/offline-chat/thread-startup-context`

读取某个正式离线协作阶段的线程启动上下文。

这是公开读取接口，不要求本机 `管理令牌`。

线程历史、同步状态刷新和发送消息仍然走受保护读写。

当前只支持：

- `phase=phase_1`

返回值至少包含：

- `phaseKey`
- `threadId=group`
- `groupThread`
- `coreParticipants`
- `supportParticipants`
- `recommendedSequence`
- `rules`
- `parallelSubagentPolicy`
- `subagentPlan`
- `parallelizationPolicy`

其中线程默认协作口径是：先由主控串行收口目标、边界、验收和关键依赖；只有独立任务、明确边界、写入范围不冲突时，才做最小必要并行。

另外当前会同步一份可直接执行的并行 subagent 真值：

- `parallelSubagentPolicy`：主控闸门、最大并行数、放行条件、阻塞条件，以及当前 `automatic_fanout` 执行模式
- `subagentPlan`：每个线程角色的批次、激活阶段、依赖关系、写入范围、并行候选关系

静态规则继续留在 `thread-startup-context`；某一轮群聊真正放行了谁、按什么批次执行、哪些角色被暂缓，会写进 group message response 和 group history 顶层的 `dispatch / execution` 真值，不再只停留在配置模式。

如果 phase 不受支持，会返回 `404` 和 `supportedPhases`。

### `GET /`

公开运行态首页。它不再承载旧混合控制台，只回答 4 件事：服务是否活着、正式恢复周期是否仍在窗口内、自动恢复有没有越过值班边界、以及下一步该去哪个专门页面。

它不再承诺消费 repair / credential deep-link 上下文；从修复中枢返回 `/` 时，总是回到“公开运行态真值”本身。

如果 URL 还带着旧参数，首页会忽略这些 repair / credential / status-list 上下文，只回到公开运行态真值。下一层页面现在固定留在：

- `/operator`
- `/repair-hub`
- `/offline-chat`
- `/lab.html`

### `POST /api/agents/compare/verify`

校验 Agent 比较审计证据包。

请求体可以直接传 `credential`，或者传整个 `evidence` 包。返回值和现有证据校验保持一致，便于 agent 自动复核。

当前校验结果除了 `hashMatches`、`issuerKnown` 之外，也会返回 `signatureRequired`、`signatureMatches` 和 `expectedVerificationMethod`。

### `GET /api/credentials`

查看本地全部证据状态，可选 `agentId`、`proposalId`、`kind`、`status`、`didMethod`、`issuerDid`、`issuerAgentId`、`repaired`、`repairId`、`sortBy`、`sortOrder`、`limit`、`repairLimit`、`repairOffset`、`repairSortBy`、`repairSortOrder` 过滤。

这个接口返回 `credentials` 和 `counts`，适合做证据中枢里的状态列表、撤销后回放和多窗口共享视图。
现在也可以直接用 `kind=migration_receipt` 查看 repair 回执历史。

列表里的每条证据现在会带 `issuerDidMethod`、`issuedByDidMethod`、`statusListDidMethod`、`repairedBy`、`repairIds`、`repairCount`、`latestRepairAt`，`counts.byDidMethod` 也会按 DID method 聚合，同时还会返回 `counts.repaired` / `counts.unrepaired` / `counts.repairGroups`。

返回值顶层现在还会带一个 `repairs` 数组，直接把当前这批证据关联到的 migration repair 聚合出来，方便 agent 不必自己二次归并：

- `repairId`
- `summary`
- `latestIssuedAt`
- `issuedDidMethods`
- `linkedCredentialCount`
- `linkedCredentialRecordIds`
- `linkedCredentialKinds`

同时还会返回一个 `repairsPage`：

- `total`
- `limit`
- `offset`
- `hasMore`
- `latestIssuedAt`

常用筛选示例：

- `repaired=true`
- `repairId=repair_xxx`
- `sortBy=latestRepairAt&sortOrder=desc`
- `sortBy=repairCount&sortOrder=desc`
- `repairLimit=5&repairOffset=0`
- `repairSortBy=linkedCredentialCount&repairSortOrder=desc`

如果通过 `read_session` 读取，列表里的 `credentialRecord.proofValue` 会被统一置空。

### `GET /api/credentials/:credentialId`

读取某条证据的详情。

可以用 `credentialId` 或 `credentialRecordId` 直接定位到本地注册表里的那条证据记录。
返回值里会附带 `siblings`，说明同一主体、同一 kind、同一 issuerAgent 下，这条证据在不同 DID method 上有哪些并行版本、缺哪些 method、是否已经齐备。
如果这条证据是被 migration repair 补出来的，详情里还会带 `repairedBy`、`repairIds`、`repairCount`、`latestRepairAt`，以及更完整的 `repairHistory`。
如果这条证据本身是 `migration_receipt`，详情里还会附带 `migrationRepairId`、`migrationSummary` 和 `migrationLinks`，把 repair 回执和被修复的 credential / compare subject / comparison pair 显式连起来。

如果通过 `read_session` 读取：

- `credentialRecord.proofValue` 会被置空
- 原始 `credential` 会收敛成摘要视图，只保留类型、issuer、status pointer 和 proof 元信息

### `GET /api/credentials/:credentialId/timeline`

读取某条证据的时间线。

返回结果会把这条证据的签发、迁移修复、撤销等节点按时间顺序展开，适合做审计回放或前端详情展示。
如果这条证据曾被 migration repair 补签，时间线里会出现 `credential_repaired` 节点。

如果通过 `read_session` 读取，timeline 会保留顺序、时间和 actor，但 `summary / details` 会做 redaction。

### `GET /api/credentials/:credentialId/status`

读取某条证据对应的状态列表快照和当前账本内可校验的撤销状态证明。

这个接口会返回该证据当前对应的状态列表、状态索引、状态证明和本地校验信息，适合做“某条证据现在是否仍然有效”的判断。

### `POST /api/credentials/:credentialId/revoke`

撤销一条本地证据记录。

请求体可以带 `reason`、`note`、`revokedByAgentId`、`revokedByWindowId`，撤销后再走 `GET /api/credentials` 或 `POST /api/credentials/verify` 就能看到状态变化。

### `POST /api/credentials/verify`

在当前本地账本上下文里校验一条证据。

新签发的本地 VC 风格对象已经开始使用 `AgentPassportEd25519Signature2026`，而且 VC body 里的 credential / evidence / status type 也开始切到 `AgentPassport*`。

因此这里除了哈希与状态列表，也会验证：

- proof 里的本地签名是否和 DID 文档里的 `#signing-1` 对得上
- proof 是否落在正确的 verification method 上
- 新旧 `AgentPassport*` / `OpenNeed*` 类型记录是否仍然兼容可验

校验一个本地证据包。

请求体可以直接传 `credential`，或者直接传整个证据对象。返回结果会说明哈希是否匹配、发行者是否存在于当前本地账本、证据里的 ledger hash 是否和当前账本一致，以及该证据在本地注册表里是否已经被撤销，并附带当前状态列表与撤销证明。

### `GET /api/status-lists`

读取当前本地状态列表摘要。

这个接口用于查看本地状态列表的整体快照，返回状态列表 ID、条目总数、活跃 / 已撤销计数以及状态列表哈希。
如果当前账本里存在多个 Agent 身份域，会返回多条状态列表摘要。

可以传 `issuerDid` 或 `issuerAgentId` 查询某个身份域对应的状态列表。

### `GET /api/status-lists/:statusListId`

读取某个状态列表的完整快照。

返回值会包含状态列表证书、摘要和每个条目的状态信息，适合做审计、调试或前端详情面板。

### `GET /api/status-lists/compare`

比较两个状态列表，并返回它们的身份域信息、DID / 钱包 / 多签策略和条目差异。

可选参数：

- `leftStatusListId` 或 `left`
- `rightStatusListId` 或 `right`
- `leftIssuerDid`
- `rightIssuerDid`
- `leftIssuerAgentId`
- `rightIssuerAgentId`

返回值会包含两侧状态列表、两侧 issuer 的身份摘要，以及 `comparison` 对象，方便 agent 做结构化判断或自动审计。

### `GET /api/agents/:id/assets`

读取该 Agent 的资产摘要。

### `GET /api/authorizations`

查看全部授权提案，可选 `agentId` 和 `limit` 过滤。

### `POST /api/authorizations`

创建一个新的授权提案。

```json
{
  "policyAgentId": "agent_main",
  "actionType": "grant_asset",
  "title": "Bootstrap grant",
  "delaySeconds": 0,
  "expiresInSeconds": 86400,
  "approvals": ["Kane"],
  "payload": {
    "targetAgentId": "agent_xxx",
    "amount": 20,
    "reason": "bootstrap grant"
  }
}
```

### `POST /api/authorizations/:proposalId/sign`

给一个授权提案追加审批。

可选携带 `sourceWindowId`，前端会自动写入当前窗口来源；响应里会更新签名记录和最新签名时间。现在签名记录还会保留 actor 的窗口、标签和可解析身份。

### `POST /api/authorizations/:proposalId/execute`

执行一个已经满足条件的授权提案。

执行成功后会写入 `executionReceipt`，失败时也会留下失败记录和错误信息，便于回放审计。这些记录会尽量保留 actor 的身份、标签、钱包和窗口信息。

### `POST /api/authorizations/:proposalId/revoke`

撤销一个未执行的授权提案。

撤销操作也会记录发起窗口和发起者，保留完整轨迹，时间线里能直接看到撤销节点。

### `GET /api/authorizations/:proposalId/timeline`

读取某个授权提案的完整时间线。

### `GET /api/authorizations/:proposalId/credential`

导出某个授权提案的本地证据包。

这个对象会把提案状态、签名、执行记录和时间线一起封装进去，方便做审计、导出或后续升级为 VC。

可选参数：

- `didMethod=agentpassport`
- `didMethod=openneed` 只用于显式兼容历史 DID 视角
- `issueBothMethods=true`

这样可以把同一条授权记录按不同 DID method 视角签发出来，便于做迁移期双 method 校验。
传 `issueBothMethods=true` 时，响应也会附带 `alternates`，便于一次拿到双 method 记录。

### `GET /api/agents/resolve`

通过 `agentId`、`did`、`walletAddress` 或 `windowId` 反查当前本地命名空间里的对应身份。

### `POST /api/windows/link`

把当前窗口绑定到某个 Agent。

如果这个 `windowId` 已经绑定到另一个 Agent，接口现在会拒绝静默改绑，避免后续窗口归因和读会话窗口过滤被污染。

### `GET /api/windows/:windowId`

读取某个窗口的绑定状态。

### `GET /api/windows`

查看所有窗口绑定。

## 下一步

当前原型的身份、记忆、恢复和记忆稳态运行链已经进入同一套 `agent-passport` 主仓库。当前代码侧已经完成：

- `ledger.js` facade 与 runner / store / runtime memory / memory stability integration seams 的第一轮拆分。
- 记忆稳态引擎本体、runtime loader、staged / controlled adapter、自学习治理、prompt preflight 和 formal execution receipts 的门禁。
- `openneed` app / bridge / legacy compatibility 与底层本体的分层隔离。
- pre-public 恢复包、恢复演练和初始化包的新鲜度门禁。

后续继续往下接：

1. 拿到正式 deploy URL 后跑 `verify:deploy:http` 与最终 `verify:go-live` / `verify:go-live:self-hosted`。
2. 再接真正的链上 DID / 钱包地址。
3. 扩展 Verifiable Credentials、多签授权撤销与时间锁。
4. 补 Agent 信誉分与可校验履历。
5. 在外部依赖允许后，逐步缩减 `openneed` 历史兼容命名残留。
