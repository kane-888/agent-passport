$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$env:HOST = if ($env:HOST) { $env:HOST } else { "127.0.0.1" }
$env:PORT = if ($env:PORT) { $env:PORT } else { "4319" }
$env:AGENT_PASSPORT_SURFACE_MODE = if ($env:AGENT_PASSPORT_SURFACE_MODE) { $env:AGENT_PASSPORT_SURFACE_MODE } else { "local" }
$env:AGENT_PASSPORT_LEDGER_PATH = if ($env:AGENT_PASSPORT_LEDGER_PATH) { $env:AGENT_PASSPORT_LEDGER_PATH } else { Join-Path $PSScriptRoot "data\ledger.json" }
$env:AGENT_PASSPORT_READ_SESSION_STORE_PATH = if ($env:AGENT_PASSPORT_READ_SESSION_STORE_PATH) { $env:AGENT_PASSPORT_READ_SESSION_STORE_PATH } else { Join-Path $PSScriptRoot "data\read-sessions.json" }
$env:AGENT_PASSPORT_STORE_KEY_PATH = if ($env:AGENT_PASSPORT_STORE_KEY_PATH) { $env:AGENT_PASSPORT_STORE_KEY_PATH } else { Join-Path $PSScriptRoot "data\.ledger-key" }
$env:AGENT_PASSPORT_SIGNING_SECRET_PATH = if ($env:AGENT_PASSPORT_SIGNING_SECRET_PATH) { $env:AGENT_PASSPORT_SIGNING_SECRET_PATH } else { Join-Path $PSScriptRoot "data\.did-signing-master-secret" }
$env:AGENT_PASSPORT_RECOVERY_DIR = if ($env:AGENT_PASSPORT_RECOVERY_DIR) { $env:AGENT_PASSPORT_RECOVERY_DIR } else { Join-Path $PSScriptRoot "data\recovery-bundles" }
$env:AGENT_PASSPORT_SETUP_PACKAGE_DIR = if ($env:AGENT_PASSPORT_SETUP_PACKAGE_DIR) { $env:AGENT_PASSPORT_SETUP_PACKAGE_DIR } else { Join-Path $PSScriptRoot "data\device-setup-packages" }
$env:AGENT_PASSPORT_ARCHIVE_DIR = if ($env:AGENT_PASSPORT_ARCHIVE_DIR) { $env:AGENT_PASSPORT_ARCHIVE_DIR } else { Join-Path $PSScriptRoot "data\archives" }
$env:AGENT_PASSPORT_ADMIN_TOKEN_PATH = if ($env:AGENT_PASSPORT_ADMIN_TOKEN_PATH) { $env:AGENT_PASSPORT_ADMIN_TOKEN_PATH } else { Join-Path $PSScriptRoot "data\.admin-token" }

New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot "data") | Out-Null

$url = "http://127.0.0.1:$($env:PORT)/"
Start-Job -ScriptBlock {
  param($TargetUrl)
  Start-Sleep -Seconds 1
  Start-Process $TargetUrl
} -ArgumentList $url | Out-Null

Write-Host "agent-passport Windows local workspace"
Write-Host "Choose Create Passport or Login / Restore Passport on the first screen."
Write-Host "Open $url if the browser does not open automatically."
node src/server.js
