#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

export HOST="${HOST:-127.0.0.1}"
export PORT="${PORT:-4319}"
export AGENT_PASSPORT_SURFACE_MODE="${AGENT_PASSPORT_SURFACE_MODE:-local}"
export AGENT_PASSPORT_LEDGER_PATH="${AGENT_PASSPORT_LEDGER_PATH:-$PWD/data/ledger.json}"
export AGENT_PASSPORT_READ_SESSION_STORE_PATH="${AGENT_PASSPORT_READ_SESSION_STORE_PATH:-$PWD/data/read-sessions.json}"
export AGENT_PASSPORT_STORE_KEY_PATH="${AGENT_PASSPORT_STORE_KEY_PATH:-$PWD/data/.ledger-key}"
export AGENT_PASSPORT_SIGNING_SECRET_PATH="${AGENT_PASSPORT_SIGNING_SECRET_PATH:-$PWD/data/.did-signing-master-secret}"
export AGENT_PASSPORT_RECOVERY_DIR="${AGENT_PASSPORT_RECOVERY_DIR:-$PWD/data/recovery-bundles}"
export AGENT_PASSPORT_SETUP_PACKAGE_DIR="${AGENT_PASSPORT_SETUP_PACKAGE_DIR:-$PWD/data/device-setup-packages}"
export AGENT_PASSPORT_ARCHIVE_DIR="${AGENT_PASSPORT_ARCHIVE_DIR:-$PWD/data/archives}"
export AGENT_PASSPORT_ADMIN_TOKEN_PATH="${AGENT_PASSPORT_ADMIN_TOKEN_PATH:-$PWD/data/.admin-token}"

mkdir -p "$PWD/data"

url="http://127.0.0.1:$PORT/"
if command -v open >/dev/null 2>&1; then
  (sleep 1; open "$url") >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  (sleep 1; xdg-open "$url") >/dev/null 2>&1 &
fi

echo "agent-passport Linux local workspace"
echo "Choose Create Passport or Login / Restore Passport on the first screen."
echo "Open $url if the browser does not open automatically."
node src/server.js
